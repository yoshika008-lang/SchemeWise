# Architecture

This document explains what the backend is, why each piece exists, and what
changed when the logic moved out of the browser. If you are presenting this
project, read this first and `DEMO-SCRIPT.md` second.

---

## 1. What "frontend" and "backend" actually mean here

**Frontend** is the part that runs on the person's own computer, inside their
browser. It draws buttons and text. The person controls it completely — they
can open developer tools and change anything in it.

**Backend** is the part that runs on a server you control. The browser can send
it a question and read the answer, but cannot reach inside and change how the
answer was produced.

The distinction only matters when something is *at stake*. For SchemeWise,
three things are at stake:

1. **The verdict.** "You qualify for PMEGP" is a claim about the law.
2. **The money.** "Your instalment is ₹11,129" is what a family plans around.
3. **The records.** Who may change a published ceiling, and is there a trail?

All three used to be decided in the browser. All three are now decided on the
server. That single sentence is the project.

---

## 2. Before and after

### Before — one HTML file

```
┌────────────────────────────────────────────┐
│  Browser                                    │
│                                             │
│   24 scheme records (hardcoded)             │
│   eligibility rules                         │
│   EMI calculation                           │
│   admin username + password                 │
│   Gemini API key                            │
│   the user interface                        │
│                                             │
└────────────────────────────────────────────┘
```

Everything in one place, and that place belongs to the visitor.

Four concrete problems:

| Problem | What an attacker does | Consequence |
|---|---|---|
| Rules in the browser | Edits `ageRule(21, 35)` in DevTools | Hands themselves a match they are not entitled to |
| Password in the browser | Reads `ADMIN_USERS` in the source | Full admin access in ten seconds |
| API key in the browser | Copies it out of the JS | Spends your Gemini quota |
| Nothing persists | Refreshes the page | Loses the profile, shortlist and checklist |

And two problems that are not attacks at all, just bad product:

- A corrected figure requires re-sending the HTML file to every user.
- There is no record of who changed what, which no government department would accept.

### After — three tiers

```
┌─────────────────┐   HTTP + JSON    ┌──────────────────────────┐
│    Browser      │ ───────────────▶ │   Python API server      │
│                 │                  │                          │
│  draws the UI   │ ◀─────────────── │  rule engine             │
│  sends answers  │    the verdict   │  loan maths              │
│  draws results  │                  │  office ranking          │
│                 │                  │  auth + audit            │
│  decides        │                  │  Gemini key              │
│  NOTHING        │                  └───────────┬──────────────┘
└─────────────────┘                              │ SQL
                                     ┌───────────▼──────────────┐
                                     │  SQLite  (11 tables)     │
                                     │  schemes, profiles,      │
                                     │  audit_log, ...          │
                                     └──────────────────────────┘
```

Open DevTools now and the worst you can do is change what *you* see. The
server re-derives the verdict from the profile every time, and it does not
read anything the browser claims about eligibility.

---

## 3. The three tiers, in detail

### Tier 1 — the browser (`frontend/index.html`)

Presentation only. It:

- collects answers and POSTs them
- renders the JSON it gets back
- draws the SVG amortisation chart and the map pins from server-supplied numbers
- runs the Tamil/Hindi translation pass over the rendered DOM

It contains no scheme record, no rule, no rate, no password and no key. You can
verify that claim in one command:

```bash
grep -c "runEngine\|const SCHEMES\|ADMIN_USERS\|apiKey" frontend/index.html
```

### Tier 2 — the API server (`backend/`)

A small routing layer over Python's standard-library HTTP server, plus four
things worth naming separately.

**`app.py` — the framework.** In a normal project you would `pip install
flask`. We write the ~260 lines ourselves so the whole product runs on a bare
Python install. That was a deliberate trade: a demo that cannot fail because a
package did not download is worth more than a framework logo.

**`engine/` — the decisions.** Kept apart from the HTTP layer on purpose.
`matcher.py` has no idea what a request is; you can call it from a script, a
test or a future mobile app.

**`routes/` — the HTTP surface.** One file per area, so "show me everything the
admin screen can do" is one file, not a search.

**`security.py` — the sharp edges.** Hashing, signing, validation, rate limits.
One file to review.

### Tier 3 — the database (`backend/data/schemewise.db`)

SQLite. A real relational database — tables, foreign keys, transactions, SQL —
that happens to live in one file instead of a separate server process.

| Table | Holds | Notable |
|---|---|---|
| `schemes` | the 24 programme records | `active` flag: closing a window never deletes history |
| `partners` | 15 offices | `handles` lists which schemes each one accepts |
| `districts` | district centroids | used for distance |
| `sessions` | every visitor | anonymous by default |
| `users` | citizens who made an account | scrypt hash + salt |
| `profiles` | onboarding answers | one per session |
| `saved_schemes` | shortlists | |
| `tracker` | application stage + document checklist | |
| `admin_users` | staff | scrypt hash + salt, role |
| `audit_log` | **every** admin action | append-only; no API route updates or deletes it |
| `match_runs` | anonymised match results | state, district, purpose, counts — no name, phone or income |

---

## 4. How one request works, end to end

Somebody finishes onboarding and taps "See my matches".

```
1. BROWSER    PUT /api/profile   { profile: { age: 26, state: "Tamil Nadu", ... } }
                                 Authorization: Bearer <signed session token>

2. rate_limit        is this IP over its budget?            (security.py)
3. attach_identity   verify the token signature, load       (routes/_helpers.py)
                     the session from the database
4. clean_profile     drop unknown fields, clamp numbers     (engine/matcher.py)
                     to legal ranges, cap strings
5. save              write the profile row                  (db.py)
6. run_engine        for each of 24 active schemes:         (engine/matcher.py)
                       run its rules -> pass / warn / fail
                       score six areas, weight, normalise
                       classify: eligible / verify / ineligible
                     sort by score, break ties by benefit
7. record            one anonymised row in match_runs       (routes/match_routes.py)

8. RESPONSE   { profile, match: { eligible[], verify[], ineligible[], all[],
                                  ruleVersion: "2026.09.1" } }

9. BROWSER    draws it
```

Step 4 is the boundary. Everything before it is untrusted input; everything
after it is data the server vouches for.

---

## 5. The scoring model

Six areas, each weighted:

| Area | Weight | Example rule |
|---|---:|---|
| Purpose | 25% | Does the scheme fund what you asked for? |
| Applicant | 20% | Age, education, category, disability |
| Income | 15% | Family income ceiling |
| Location | 15% | State restriction, residence duration |
| Cost | 15% | Project cost floor and ceiling, loan band |
| Scheme conditions | 10% | New unit only, credit standing, sector |

Each rule returns pass (1.0), warn (0.5) or fail (0.0). An area is the mean of
its rules. The score is the weighted mean **over the weight actually used** —
so a scheme with no income rule is not punished for having no income rule.

### The part worth defending

The verdict is not the score. It is:

```
any mandatory FAIL  ->  ineligible
any mandatory WARN  ->  needs verification
otherwise           ->  confirmed match
```

**WARN means "we could not check this from what you told us."** It is never
treated as a pass. A scheme with one unanswered mandatory condition scores
well and still does not appear as a confirmed match.

This is why every education scheme in the catalogue lands in "needs
verification" and none in "confirmed": each carries a condition a form cannot
settle — the institution must be on a notified list, or a caste certificate
must be produced. The engine would rather say "prove it" than promise
something nobody verified.

That is a product decision with a real cost — fewer green ticks on screen —
and it is the right one. Telling someone they qualify when they do not costs
them a day of travel, a queue, and a refusal at a counter.

---

## 6. The AI, and why it cannot hallucinate a scheme

The order of operations is the whole design:

```
question
   │
   ▼
run the rule engine on this person's profile        ← facts are produced HERE
   │
   ▼
build a FACTS block: the exact schemes, scores,
and the sentence behind every rule that was checked
   │
   ▼
send [system rules + FACTS + conversation] to Gemini ← model only phrases them
   │
   ▼
reply
```

The system prompt says the FACTS block is the only permitted source, that a
scheme not in it does not exist for this conversation, and that anything the
engine marked "needs verification" must never be upgraded to a match.

If there is no API key, `engine_answer()` answers the same question straight
from the engine — documents, instalment, where to apply, what is missing,
or a summary of the verdict. The assistant degrades to something *more*
trustworthy, not less, and the demo cannot be broken by venue wifi.

The key itself is an environment variable read by the server.
`GET /api/ai/status` reports whether a model is configured without ever
returning the key.

---

## 7. Why an audit log, for a student project

Because the product is aimed at a government department, and the first
question a department asks about any system that publishes official figures is
*"who changed this, and when?"*

Every administrator action — sign-in, failed sign-in, record edit, enable,
disable — writes a row with the username, the action, the entity, the before
and after values, the IP address and the timestamp. There is no route in the
entire API that updates or deletes a row in that table.

Two related choices fall out of it:

- **Editing a record resets its verification date.** A changed figure cannot
  keep an old verification stamp. The UI then shows "verification overdue"
  after twelve months.
- **Administrators cannot edit rules.** The admin screen exposes an allowlist
  of record fields. Thresholds live in `engine/catalogue.py` and change only
  through a reviewed commit, so a published figure can never drift away from
  the rule that decides a match.

---

## 8. Honest limits

Worth saying out loud rather than being caught on:

- **SQLite, not Postgres.** Right for one server and a demo. A real deployment
  with concurrent writers would move to Postgres; `db.py` is the only file
  that would change.
- **No HTTPS.** The server speaks plain HTTP on localhost. Production would sit
  behind nginx or a managed load balancer terminating TLS.
- **Sessions are not revocable server-side.** Tokens expire (12 hours for
  citizens, 4 for admins) but there is no deny-list yet. That is a `revoked`
  table and one check in `attach_identity`.
- **The office directory is sample data.** Institutions and roles are real;
  addresses and coordinates are approximate, and the app says so on screen.
- **24 schemes, 5 states.** The architecture does not care — schemes are rows,
  and `GET /api/schemes` already filters server-side so 2,000 records would
  send 20, not 2,000. Each new scheme needs its rule set written and reviewed,
  which is the intended bottleneck.
- **No tests beyond `selftest.py`.** It is 43 end-to-end checks, not a unit
  suite. It catches regressions in everything that matters; it is not pytest.
