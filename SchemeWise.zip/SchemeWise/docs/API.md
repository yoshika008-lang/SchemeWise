# API reference

33 endpoints. Base URL `http://localhost:8000`. Everything speaks JSON.

The server also documents itself — **`GET /api/docs`** is generated from the
live routing table, so it can never drift out of date with the code.

## Authentication

Two kinds of token, both signed with HMAC-SHA256 and sent the same way:

```
Authorization: Bearer <token>
```

| Token | From | Lasts | Reaches |
|---|---|---|---|
| citizen session | `POST /api/session` (automatic on page load) | 12 h | profile, shortlist, tracker |
| administrator | `POST /api/admin/login` | 4 h | everything under `/api/admin/` |

A token whose payload has been edited fails its signature check and is
rejected as "not signed in". Admin routes without a valid admin token return
401 regardless of what the browser thinks.

---

## Public

### `GET /api/health`
Is the server up and the database reachable. Keep this open in a tab during a demo.

```json
{ "status": "ok", "version": "1.0.0", "database": "connected",
  "schemes": 24, "partners": 15, "uptime": "0h 4m 12s" }
```

### `GET /api/docs`
Every route, grouped, with a one-line summary pulled from each handler's docstring.

### `GET /api/schemes`
The catalogue. Filters are applied **on the server**, so a deployment with
2,000 schemes sends 20, not 2,000.

`?type=Business` `?state=Tamil Nadu` `?purpose=start_business` `?q=food`

```json
{ "schemes": [ { "id": "pmegp", "name": "...", "rate": {"min":10.5,"max":13,"fixed":false}, ... } ],
  "count": 24, "total": 24 }
```

Note what is **not** in the response: `rules`. The rules decide, and they stay
on the server. Deactivated schemes are invisible here unless the caller holds
an admin token.

### `GET /api/schemes/:id`
One record. 404 if it does not exist or is not published.

### `GET /api/reference`
Districts with coordinates, the office directory, office-type labels, scheme
types. The frontend calls this once at boot to fill its dropdowns and map.

---

## Matching — the core

### `POST /api/match`

**This is the endpoint to show a judge.** Answers in, verdict out.

```json
{ "profile": { "age": 26, "state": "Tamil Nadu", "district": "Coimbatore",
               "income": 300000, "education": "degree",
               "requirement": "start_business", "sector": "food_processing",
               "stage": "new", "projectCost": 800000, "amountNeeded": 720000 } }
```

```json
{
  "ruleVersion": "2026.09.1",
  "counts": { "eligible": 5, "verify": 9, "ineligible": 10, "evaluated": 24 },
  "eligible": [
    {
      "scheme": { "id": "pmfme", "name": "PM Formalisation of Micro Food ...", ... },
      "score": 100,
      "status": "eligible",
      "value": 25.4,
      "groups": { "purpose": 1.0, "applicant": 1.0, "income": 1.0,
                  "location": 1.0, "cost": 1.0, "scheme": 1.0 },
      "results": [
        { "group": "purpose", "label": "Purpose requirement", "mandatory": true,
          "status": "pass", "note": "Your stated requirement is a funded purpose" },
        { "group": "scheme", "label": "Sector requirement", "mandatory": true,
          "status": "pass", "note": "food processing and value addition is an eligible activity" }
      ],
      "blocking": [], "warnings": [], "conditions": [ ... ]
    }
  ],
  "verify": [ ... ], "ineligible": [ ... ], "all": [ ... ]
}
```

Three things to point at in that response:

- **`note` on every rule.** The verdict shows its working. Nothing is a black box.
- **`warnings` vs `blocking`.** A warning is "we could not check this", and it
  moves the scheme out of `eligible` into `verify`. It is never a pass.
- **`ruleVersion`.** The verdict is reproducible against the rules that made it.

Unknown fields in the profile are dropped, numbers are clamped to legal
ranges, and strings are capped, before a single rule runs.

### `POST /api/match/subsidy`
What one scheme is worth to this applicant, in rupees.

---

## Profile, shortlist, checklist

Every route here is scoped to the caller's own session token. There is no
route that takes a session id as a parameter, so there is no way to ask the
server for somebody else's data.

| | |
|---|---|
| `PUT /api/profile` | Save the answers **and** return the fresh match in the same response — one round trip. |
| `GET /api/profile` | Read it back. This is why a page refresh does not lose your work. |
| `GET /api/saved` · `POST /api/saved/:schemeId` | Shortlist; POST toggles. |
| `GET /api/tracker` · `PUT /api/tracker/:schemeId` | Application stage and per-document state (`need` / `ready` / `na`). |

---

## Calculator

### `POST /api/finance/quote`

```json
{ "schemeId": "pmegp", "cost": 800000, "rate": 11, "years": 7,
  "moratoriumMonths": 6, "contributionPct": 10, "profile": { ... } }
```

```json
{ "projectCost": 800000, "eligibleFinancing": 720000,
  "subsidy": { "pct": 15, "amount": 120000, "label": "15% margin money subsidy (urban rate)" },
  "contribution": 80000, "loan": 600000,
  "emi": 11129.15, "morInterest": 35250.0,
  "totalInterest": 334848.6, "totalRepayment": 934848.6,
  "schedule": [ { "year": 1, "balance": 562243 }, ... ],
  "months": 84, "computedOn": "server" }
```

Open the Network tab and drag the project-cost slider: one request per pause.
The browser does no arithmetic — it renders `emi`.

`morInterest` is reported separately because that is the figure people are
surprised by later: during a moratorium you do not pay, but interest still
accrues and is capitalised.

### `POST /api/finance/compare`
The same project costed against every financing scheme at once, cheapest total
repayment first. A server-side join across records — not something the page
could work out on its own.

---

## Offices

### `POST /api/partners/route`

```json
{ "schemeId": "pmegp", "state": "Tamil Nadu", "district": "Coimbatore",
  "origin": [11.0168, 76.9558], "kind": "all" }
```

Ranked **50% does this office handle your scheme, 25% office type, 25%
distance** — so a District Industries Centre three kilometres further away
outranks the bank on the corner. Distance alone sends people to the wrong
counter, which is the failure this product exists to prevent.

The response says which origin it used (`device`, `district` or `default`), so
the page can be honest about the distances it shows.

---

## Assistant

### `POST /api/ai/chat`

```json
{ "messages": [ { "role": "u", "text": "what documents do I need?" } ],
  "profile": { ... }, "schemeId": "pmegp", "lang": "en" }
```

```json
{ "reply": "**PMFME** asks for:\n- Aadhaar and PAN\n- ...",
  "source": "rule-engine", "grounded": true }
```

`source` is either `gemini` or `rule-engine`. The server runs the eligibility
engine **first** and injects the verdict into the prompt as the only facts the
model may use, so it cannot name a scheme that is not in the result set. With
no API key configured, the same endpoint answers straight from the engine.

### `POST /api/ai/explain`
Plain-language summary of a result set (`kind: "results"`) or one scheme
(`kind: "scheme"`), in `en` / `ta` / `hi`.

### `GET /api/ai/status`
Reports whether a model is configured — without ever returning the key.

```json
{ "modelConfigured": false, "keyLocation": "server environment variable GEMINI_API_KEY",
  "fallback": "rule-engine", "keyExposedToBrowser": false }
```

---

## Administration

All of these require an admin token. Without one: **401**, every time.

### `POST /api/admin/login`
Username and password. The password is checked against a scrypt hash. Both
success and failure write an audit row.

### `GET /api/admin/schemes`
All 24 records including unpublished ones, each with the number of published
rules governing it.

### `PATCH /api/admin/schemes/:id`
Edit a record. Only an **allowlist** of fields is accepted — anything else in
the body is ignored, and every numeric field is bounds-checked:

```bash
# rejected: "maxFinancing must be between 0 and 1000000000"
curl -X PATCH .../api/admin/schemes/pmegp -d '{"maxFinancing": 99999999999}'
```

Two behaviours worth naming:

- The edit **resets the verification date**, so a changed figure cannot keep an
  old stamp.
- Eligibility **thresholds are not editable here**. They live in
  `backend/engine/catalogue.py` and change only through a reviewed commit.

### `POST /api/admin/schemes/:id/toggle`
Publish or unpublish. Unpublishing hides a scheme from citizens without
deleting its history.

### `GET /api/admin/audit`
The append-only trail.

```json
{ "entries": [ { "actor": "admin", "action": "update", "entity": "scheme",
    "entityId": "pmegp", "ip": "127.0.0.1", "at": "2026-09-12T11:05:21",
    "before": { "maxFinancing": 5000000, "lastVerified": "2026-08-30" },
    "after":  { "maxFinancing": 4200000, "lastVerified": "2026-09-12" } } ],
  "total": 7, "appendOnly": true }
```

### `GET /api/admin/stats`
Catalogue health (including how many records are overdue for verification),
usage counts, and aggregate demand — top requirements, top districts, most
recommended schemes, average matches per run, and how many runs found nothing.

Every figure is a `COUNT` over anonymised rows. There is no query in this
endpoint that returns anything about one identifiable person.

---

## Errors

Consistent shape, readable message, correct status code:

```json
{ "error": "No scheme with id 'does-not-exist'", "status": 404 }
```

| | |
|---|---|
| 400 | bad input — the message names the field and the rule |
| 401 | missing, expired or forged token |
| 403 | valid token, insufficient role |
| 404 | no such record |
| 405 | wrong method for that path |
| 429 | rate limited — the message says how long to wait |
| 500 | logged with a traceback on the server; the client gets no internals |

## Rate limits

Per IP, token bucket:

| Bucket | Burst | Refill |
|---|---:|---|
| reads | 240 | 10/s |
| writes | 90 | 2/s |
| AI | 12 | 1 per 10 s |
| sign-in / register | 8 | 1 per 20 s |
