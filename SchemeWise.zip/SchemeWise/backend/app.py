"""
SchemeWise — minimal HTTP framework.

This file is the "web framework" layer. In a normal project you would install
Flask or FastAPI and get this for free. We write it ourselves (about 260 lines)
so the whole backend runs on a plain Python install with zero `pip install`,
which means it starts on any machine at a demo venue with no internet.

What it gives us, exactly like Flask would:

    @app.route("GET", "/api/schemes/:id")
    def get_scheme(req):
        return {"scheme": ...}          # -> 200 application/json

    raise HttpError(404, "No such scheme")   # -> 404 {"error": "..."}

Concepts:
  Request   what the browser sent us (method, path, query, JSON body, headers)
  Response  what we send back
  App       the routing table + middleware chain
  HttpError an exception that becomes a clean JSON error response
"""

import json
import re
import sys
import time
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs


# ----------------------------------------------------------------------------
# Errors
# ----------------------------------------------------------------------------

class HttpError(Exception):
    """Raise this anywhere in a route to return a clean JSON error."""

    def __init__(self, status, message, details=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.details = details


# ----------------------------------------------------------------------------
# Request / Response
# ----------------------------------------------------------------------------

class Request:
    def __init__(self, method, path, query, headers, body, ip):
        self.method = method
        self.path = path
        self.query = query            # {"state": "Tamil Nadu"}
        self.headers = headers
        self.raw_body = body
        self.ip = ip
        self.params = {}              # filled by the router: /:id -> {"id": "pmegp"}
        self.session = None           # filled by auth middleware
        self.admin = None             # filled by auth middleware
        self.started = time.time()
        self._json = None

    @property
    def json(self):
        """Parsed JSON body. Returns {} when the body is empty."""
        if self._json is None:
            if not self.raw_body:
                self._json = {}
            else:
                try:
                    parsed = json.loads(self.raw_body.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    raise HttpError(400, "Request body is not valid JSON")
                if not isinstance(parsed, dict):
                    raise HttpError(400, "Request body must be a JSON object")
                self._json = parsed
        return self._json

    def q(self, name, default=None):
        """One value from the query string: /api/schemes?type=Business"""
        vals = self.query.get(name)
        return vals[0] if vals else default

    def bearer(self):
        """The token from `Authorization: Bearer <token>`, or None."""
        raw = self.headers.get("Authorization") or self.headers.get("authorization") or ""
        if raw.lower().startswith("bearer "):
            return raw[7:].strip()
        return None


class Response:
    def __init__(self, body, status=200, headers=None, content_type="application/json; charset=utf-8"):
        self.body = body
        self.status = status
        self.content_type = content_type
        self.headers = headers or {}


# ----------------------------------------------------------------------------
# App — routing table + middleware
# ----------------------------------------------------------------------------

_PARAM = re.compile(r":([A-Za-z_][A-Za-z0-9_]*)")


def _compile(pattern):
    """Turn "/api/schemes/:id" into a regex that captures id."""
    escaped = re.escape(pattern).replace(r"\:", ":")
    regex = _PARAM.sub(r"(?P<\1>[^/]+)", escaped)
    return re.compile("^" + regex + "$")


class App:
    def __init__(self):
        self.routes = []          # (method, compiled_regex, handler, pattern)
        self.middleware = []      # callables run before every route
        self.static_dirs = []     # (url_prefix, filesystem_path)

    def route(self, method, pattern):
        compiled = _compile(pattern)

        def wrap(fn):
            self.routes.append((method.upper(), compiled, fn, pattern))
            return fn

        return wrap

    def get(self, p):
        return self.route("GET", p)

    def post(self, p):
        return self.route("POST", p)

    def put(self, p):
        return self.route("PUT", p)

    def patch(self, p):
        return self.route("PATCH", p)

    def delete(self, p):
        return self.route("DELETE", p)

    def use(self, fn):
        """Register middleware. It runs before the route handler."""
        self.middleware.append(fn)
        return fn

    def static(self, url_prefix, directory):
        self.static_dirs.append((url_prefix, directory))

    # -- dispatch -------------------------------------------------------------

    def match(self, method, path):
        allowed = set()
        for m, regex, fn, pattern in self.routes:
            hit = regex.match(path)
            if hit:
                if m == method:
                    return fn, hit.groupdict()
                allowed.add(m)
        if allowed:
            raise HttpError(405, "Method %s is not allowed on %s" % (method, path))
        return None, None

    def handle(self, req):
        """Run middleware then the matching route. Always returns a Response."""
        try:
            handler, params = self.match(req.method, req.path)
            if handler is None:
                raise HttpError(404, "No API route for %s %s" % (req.method, req.path))
            req.params = params or {}

            for mw in self.middleware:
                early = mw(req)
                if early is not None:
                    return _as_response(early)

            return _as_response(handler(req))

        except HttpError as e:
            payload = {"error": e.message, "status": e.status}
            if e.details:
                payload["details"] = e.details
            return Response(payload, status=e.status)

        except Exception:
            traceback.print_exc()
            return Response(
                {"error": "Internal server error", "status": 500},
                status=500,
            )


def _as_response(value):
    if isinstance(value, Response):
        return value
    if isinstance(value, tuple) and len(value) == 2:
        body, status = value
        return Response(body, status=status)
    return Response(value)


# ----------------------------------------------------------------------------
# The actual socket server
# ----------------------------------------------------------------------------

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Session-Token",
    "Access-Control-Max-Age": "600",
}

MAX_BODY = 1024 * 512  # 512 KB is far more than any request here needs


class _Handler(BaseHTTPRequestHandler):
    server_version = "SchemeWise/1.0"
    protocol_version = "HTTP/1.1"

    # -- plumbing -------------------------------------------------------------

    def log_message(self, fmt, *args):
        # One tidy line per request instead of the noisy default.
        pass

    def _read_body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return b""
        if length > MAX_BODY:
            return b""
        return self.rfile.read(length)

    def _send(self, response):
        if isinstance(response.body, (bytes, bytearray)):
            payload = bytes(response.body)
        else:
            payload = json.dumps(response.body, ensure_ascii=False, default=str).encode("utf-8")

        self.send_response(response.status)
        self.send_header("Content-Type", response.content_type)
        self.send_header("Content-Length", str(len(payload)))
        for k, v in CORS_HEADERS.items():
            self.send_header(k, v)
        for k, v in response.headers.items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # -- verbs ----------------------------------------------------------------

    def do_OPTIONS(self):
        self.send_response(204)
        for k, v in CORS_HEADERS.items():
            self.send_header(k, v)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _dispatch(self, method):
        app = self.server.app
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"

        # Static files (the frontend) are served outside the API router.
        if method == "GET":
            static = self.server.serve_static(parsed.path)
            if static is not None:
                self._send(static)
                self._log(method, parsed.path, static.status, 0)
                return

        req = Request(
            method=method,
            path=path,
            query=parse_qs(parsed.query),
            headers=self.headers,
            body=self._read_body(),
            ip=self.client_address[0] if self.client_address else "?",
        )
        response = app.handle(req)
        self._send(response)
        self._log(method, path, response.status, (time.time() - req.started) * 1000)

    def _log(self, method, path, status, ms):
        colour = "" if status < 400 else "!"
        print("  %-6s %-38s %s%s  %5.1fms" % (method, path[:38], status, colour, ms))

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_DELETE(self):
        self._dispatch("DELETE")


class Server(ThreadingHTTPServer):
    """Threaded so several browser tabs (and the judge's phone) can talk at once."""

    daemon_threads = True

    # On Unix, SO_REUSEADDR only lets you rebind a port stuck in TIME_WAIT after
    # a restart, which is what we want. On Windows it also lets a SECOND server
    # bind a port a live server already holds — and then it is undefined which
    # of the two answers. That produces the worst possible symptom: you restart
    # the server, your edits do not appear, and nothing reports an error.
    # So on Windows we refuse instead, and server.py prints how to pick a
    # different port.
    allow_reuse_address = not sys.platform.startswith("win")

    def __init__(self, address, app, static_root=None):
        super().__init__(address, _Handler)
        self.app = app
        self.static_root = static_root

    def serve_static(self, url_path):
        if not self.static_root:
            return None
        return self.static_root(url_path)


def run(app, host, port, static_root=None):
    server = Server((host, port), app, static_root)
    server.serve_forever()
