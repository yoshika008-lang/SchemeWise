"""
SchemeWise — database layer (SQLite).

SQLite is a real relational database: tables, foreign keys, transactions, SQL.
It just happens to live in one file (backend/data/schemewise.db) instead of a
separate server process, so there is nothing to install or configure.

Eleven tables:

    users            citizens who chose to create an account
    sessions         every visitor, signed in or not
    profiles         the answers someone gave in onboarding
    schemes          the 24 government programmes (the records)
    partners         offices and banks that accept applications
    districts        district centroids, for distance
    saved_schemes    a citizen's shortlist
    tracker          per-scheme application status and document checklist
    admin_users      staff who may edit scheme records
    audit_log        who changed what, when, from which IP  <- governance
    match_runs       anonymised record of each match, for analytics

Note what is NOT in here: the eligibility rules. Records are data and admins
edit them; rules are logic and live in version-controlled code (engine/).
That separation is deliberate and is explained in docs/ARCHITECTURE.md.
"""

import json
import os
import sqlite3
import threading
import time

DB_DIR = os.path.join(os.path.dirname(__file__), "data")
DB_PATH = os.path.join(DB_DIR, "schemewise.db")
SEED_DIR = os.path.join(os.path.dirname(__file__), "seed")

_local = threading.local()


# ----------------------------------------------------------------------------
# Connections
# ----------------------------------------------------------------------------

def connect():
    """
    One connection per thread. SQLite connections are not safe to share across
    threads, and our server is threaded, so each thread gets its own.
    """
    conn = getattr(_local, "conn", None)
    if conn is None:
        os.makedirs(DB_DIR, exist_ok=True)
        conn = sqlite3.connect(DB_PATH, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")      # readers don't block writers
        conn.execute("PRAGMA foreign_keys=ON")       # enforce the relationships
        conn.execute("PRAGMA busy_timeout=5000")
        _local.conn = conn
    return conn


def query(sql, args=()):
    """Read many rows."""
    return connect().execute(sql, args).fetchall()


def query_one(sql, args=()):
    """Read one row, or None."""
    return connect().execute(sql, args).fetchone()


def execute(sql, args=()):
    """Write. Commits immediately."""
    conn = connect()
    cur = conn.execute(sql, args)
    conn.commit()
    return cur


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


# ----------------------------------------------------------------------------
# Schema
# ----------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  phone         TEXT UNIQUE NOT NULL,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  last_seen  TEXT NOT NULL,
  ip         TEXT
);

CREATE TABLE IF NOT EXISTS profiles (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_token TEXT NOT NULL REFERENCES sessions(token) ON DELETE CASCADE,
  user_id       INTEGER REFERENCES users(id) ON DELETE CASCADE,
  data          TEXT NOT NULL,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  UNIQUE(session_token)
);

CREATE TABLE IF NOT EXISTS schemes (
  id                TEXT PRIMARY KEY,
  name              TEXT NOT NULL,
  short             TEXT NOT NULL,
  agency            TEXT NOT NULL,
  type              TEXT NOT NULL,
  purposes          TEXT NOT NULL,
  beneficiaries     TEXT NOT NULL,
  states            TEXT NOT NULL,
  income_limit      INTEGER,
  project_min       INTEGER NOT NULL DEFAULT 0,
  project_max       INTEGER NOT NULL DEFAULT 0,
  max_financing     INTEGER NOT NULL DEFAULT 0,
  financing_pct     INTEGER NOT NULL DEFAULT 0,
  subsidy_text      TEXT NOT NULL,
  rate_min          REAL NOT NULL DEFAULT 0,
  rate_max          REAL NOT NULL DEFAULT 0,
  rate_fixed        INTEGER NOT NULL DEFAULT 0,
  repayment_years   INTEGER NOT NULL DEFAULT 0,
  moratorium_months INTEGER NOT NULL DEFAULT 0,
  documents         TEXT NOT NULL,
  apply_text        TEXT NOT NULL,
  official          TEXT NOT NULL,
  helpline          TEXT,
  partner_types     TEXT NOT NULL,
  last_verified     TEXT NOT NULL,
  confidence        TEXT NOT NULL,
  active            INTEGER NOT NULL DEFAULT 1,
  updated_at        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS partners (
  id       TEXT PRIMARY KEY,
  name     TEXT NOT NULL,
  kind     TEXT NOT NULL,
  area     TEXT NOT NULL,
  district TEXT NOT NULL,
  state    TEXT NOT NULL,
  lat      REAL NOT NULL,
  lng      REAL NOT NULL,
  handles  TEXT NOT NULL,
  types    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS districts (
  state    TEXT NOT NULL,
  district TEXT NOT NULL,
  lat      REAL NOT NULL,
  lng      REAL NOT NULL,
  PRIMARY KEY (state, district)
);

CREATE TABLE IF NOT EXISTS saved_schemes (
  session_token TEXT NOT NULL REFERENCES sessions(token) ON DELETE CASCADE,
  scheme_id     TEXT NOT NULL REFERENCES schemes(id) ON DELETE CASCADE,
  created_at    TEXT NOT NULL,
  PRIMARY KEY (session_token, scheme_id)
);

CREATE TABLE IF NOT EXISTS tracker (
  session_token TEXT NOT NULL REFERENCES sessions(token) ON DELETE CASCADE,
  scheme_id     TEXT NOT NULL REFERENCES schemes(id) ON DELETE CASCADE,
  status        TEXT NOT NULL DEFAULT 'not_started',
  docs          TEXT NOT NULL DEFAULT '{}',
  updated_at    TEXT NOT NULL,
  PRIMARY KEY (session_token, scheme_id)
);

CREATE TABLE IF NOT EXISTS admin_users (
  username      TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  role          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  created_at    TEXT NOT NULL,
  last_login    TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor      TEXT NOT NULL,
  action     TEXT NOT NULL,
  entity     TEXT NOT NULL,
  entity_id  TEXT,
  before     TEXT,
  after      TEXT,
  ip         TEXT,
  at         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS match_runs (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  session_token    TEXT,
  state            TEXT,
  district         TEXT,
  requirement      TEXT,
  category         TEXT,
  eligible_count   INTEGER NOT NULL,
  verify_count     INTEGER NOT NULL,
  ineligible_count INTEGER NOT NULL,
  top_scheme       TEXT,
  at               TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_at        ON audit_log(at DESC);
CREATE INDEX IF NOT EXISTS idx_runs_at         ON match_runs(at DESC);
CREATE INDEX IF NOT EXISTS idx_saved_session   ON saved_schemes(session_token);
CREATE INDEX IF NOT EXISTS idx_tracker_session ON tracker(session_token);
CREATE INDEX IF NOT EXISTS idx_schemes_active  ON schemes(active);
"""


# ----------------------------------------------------------------------------
# Row <-> API shape
# ----------------------------------------------------------------------------
# The database stores snake_case columns; the frontend speaks camelCase and
# expects lists as real arrays. These two functions are the only place that
# translation happens.

def scheme_to_api(row):
    return {
        "id": row["id"],
        "name": row["name"],
        "short": row["short"],
        "agency": row["agency"],
        "type": row["type"],
        "purposes": json.loads(row["purposes"]),
        "beneficiaries": row["beneficiaries"],
        "states": json.loads(row["states"]),
        "incomeLimit": row["income_limit"],
        "projectMin": row["project_min"],
        "projectMax": row["project_max"],
        "maxFinancing": row["max_financing"],
        "financingPct": row["financing_pct"],
        "subsidyText": row["subsidy_text"],
        "rate": {
            "min": row["rate_min"],
            "max": row["rate_max"],
            "fixed": bool(row["rate_fixed"]),
        },
        "repaymentYears": row["repayment_years"],
        "moratoriumMonths": row["moratorium_months"],
        "documents": json.loads(row["documents"]),
        "applyText": row["apply_text"],
        "official": row["official"],
        "helpline": row["helpline"],
        "partnerTypes": json.loads(row["partner_types"]),
        "lastVerified": row["last_verified"],
        "confidence": row["confidence"],
        "active": bool(row["active"]),
    }


def partner_to_api(row):
    return {
        "id": row["id"],
        "name": row["name"],
        "kind": row["kind"],
        "area": row["area"],
        "district": row["district"],
        "state": row["state"],
        "lat": row["lat"],
        "lng": row["lng"],
        "handles": json.loads(row["handles"]),
        "types": json.loads(row["types"]),
    }


def all_schemes(include_inactive=False):
    sql = "SELECT * FROM schemes"
    if not include_inactive:
        sql += " WHERE active = 1"
    sql += " ORDER BY rowid"
    return [scheme_to_api(r) for r in query(sql)]


def get_scheme(scheme_id, include_inactive=True):
    sql = "SELECT * FROM schemes WHERE id = ?"
    if not include_inactive:
        sql += " AND active = 1"
    row = query_one(sql, (scheme_id,))
    return scheme_to_api(row) if row else None


def all_partners():
    return [partner_to_api(r) for r in query("SELECT * FROM partners ORDER BY rowid")]


def all_districts():
    """{"Tamil Nadu": {"Coimbatore": [lat, lng], ...}, ...}"""
    out = {}
    for r in query("SELECT * FROM districts ORDER BY state, district"):
        out.setdefault(r["state"], {})[r["district"]] = [r["lat"], r["lng"]]
    return out


def audit(actor, action, entity, entity_id=None, before=None, after=None, ip=None):
    """
    Append-only record of every change an administrator makes. Nothing in the
    API ever updates or deletes a row in this table.
    """
    execute(
        "INSERT INTO audit_log (actor, action, entity, entity_id, before, after, ip, at)"
        " VALUES (?,?,?,?,?,?,?,?)",
        (
            actor,
            action,
            entity,
            entity_id,
            json.dumps(before, default=str) if before is not None else None,
            json.dumps(after, default=str) if after is not None else None,
            ip,
            now(),
        ),
    )


# ----------------------------------------------------------------------------
# Seeding
# ----------------------------------------------------------------------------

def _read_seed(filename):
    with open(os.path.join(SEED_DIR, filename), "r", encoding="utf-8") as fh:
        return json.load(fh)


def _seed_schemes():
    rows = _read_seed("schemes.json")
    conn = connect()
    for s in rows:
        conn.execute(
            """INSERT OR IGNORE INTO schemes
               (id, name, short, agency, type, purposes, beneficiaries, states,
                income_limit, project_min, project_max, max_financing, financing_pct,
                subsidy_text, rate_min, rate_max, rate_fixed, repayment_years,
                moratorium_months, documents, apply_text, official, helpline,
                partner_types, last_verified, confidence, active, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                s["id"], s["name"], s["short"], s["agency"], s["type"],
                json.dumps(s["purposes"]), s["beneficiaries"], json.dumps(s["states"]),
                s.get("incomeLimit"), s.get("projectMin", 0), s.get("projectMax", 0),
                s.get("maxFinancing", 0), s.get("financingPct", 0),
                s["subsidyText"], s["rate"]["min"], s["rate"]["max"],
                1 if s["rate"]["fixed"] else 0,
                s.get("repaymentYears", 0), s.get("moratoriumMonths", 0),
                json.dumps(s["documents"]), s["applyText"], s["official"],
                s.get("helpline"), json.dumps(s.get("partnerTypes", [])),
                s["lastVerified"], s["confidence"], 1, now(),
            ),
        )
    conn.commit()
    return len(rows)


def _seed_partners():
    rows = _read_seed("partners.json")
    conn = connect()
    for p in rows:
        conn.execute(
            """INSERT OR IGNORE INTO partners
               (id, name, kind, area, district, state, lat, lng, handles, types)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (p["id"], p["name"], p["kind"], p["area"], p["district"], p["state"],
             p["lat"], p["lng"], json.dumps(p["handles"]), json.dumps(p["types"])),
        )
    conn.commit()
    return len(rows)


def _seed_districts():
    data = _read_seed("districts.json")
    conn = connect()
    count = 0
    for state, districts in data.items():
        for district, coords in districts.items():
            conn.execute(
                "INSERT OR IGNORE INTO districts (state, district, lat, lng) VALUES (?,?,?,?)",
                (state, district, coords[0], coords[1]),
            )
            count += 1
    conn.commit()
    return count


def _seed_admins():
    """
    Default staff accounts. The passwords below are hashed before they touch
    the database, and they are meant to be changed with:
        python backend/manage.py set-admin-password <username>
    """
    import security

    defaults = [
        ("admin", "Scheme Administrator", "super_admin", "scheme@2025"),
        ("verifier", "Record Verifier", "verification_officer", "verify@2025"),
    ]
    created = 0
    for username, name, role, password in defaults:
        if query_one("SELECT username FROM admin_users WHERE username = ?", (username,)):
            continue
        digest, salt = security.hash_password(password)
        execute(
            "INSERT INTO admin_users (username, name, role, password_hash, password_salt, created_at)"
            " VALUES (?,?,?,?,?,?)",
            (username, name, role, digest, salt, now()),
        )
        created += 1
    return created


def init(verbose=True):
    """Create the schema if needed, then load seed data on a fresh database."""
    conn = connect()
    conn.executescript(SCHEMA)
    conn.commit()

    counts = {
        "schemes": _seed_schemes(),
        "partners": _seed_partners(),
        "districts": _seed_districts(),
        "admins": _seed_admins(),
    }

    if verbose:
        total = query_one("SELECT COUNT(*) c FROM schemes")["c"]
        print("  database  %s" % DB_PATH)
        print("  tables    11 created/verified")
        print("  schemes   %d records loaded" % total)
        print("  partners  %d offices" % query_one("SELECT COUNT(*) c FROM partners")["c"])
        if counts["admins"]:
            print("  admins    %d default accounts created" % counts["admins"])
    return counts
