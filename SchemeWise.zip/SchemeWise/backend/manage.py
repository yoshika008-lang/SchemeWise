"""
SchemeWise — admin tasks.

    python backend/manage.py list-admins
    python backend/manage.py set-admin-password <username>
    python backend/manage.py add-admin <username> "<Full Name>" <role>
    python backend/manage.py reset-demo
    python backend/manage.py stats

Change the demo passwords before anyone else can reach your machine:

    python backend/manage.py set-admin-password admin
"""

import getpass
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import db          # noqa: E402
import security    # noqa: E402

ROLES = ["super_admin", "verification_officer"]


def list_admins():
    db.init(verbose=False)
    rows = db.query("SELECT username, name, role, created_at, last_login FROM admin_users ORDER BY username")
    print("\n  %-14s %-26s %-22s %s" % ("USERNAME", "NAME", "ROLE", "LAST SIGN-IN"))
    print("  " + "-" * 84)
    for r in rows:
        print("  %-14s %-26s %-22s %s" % (r["username"], r["name"], r["role"], r["last_login"] or "never"))
    print("")


def set_password(username):
    db.init(verbose=False)
    row = db.query_one("SELECT username FROM admin_users WHERE username = ?", (username,))
    if not row:
        print("\n  No administrator called '%s'. Run list-admins to see who exists.\n" % username)
        return 1

    first = getpass.getpass("  New password for %s: " % username)
    again = getpass.getpass("  Type it again: ")
    if first != again:
        print("\n  Those did not match. Nothing was changed.\n")
        return 1

    digest, salt = security.hash_password(first)
    db.execute("UPDATE admin_users SET password_hash = ?, password_salt = ? WHERE username = ?",
               (digest, salt, username))
    db.audit("manage.py", "password_change", "admin_user", username)
    print("\n  Password updated. The old one no longer works.\n")
    return 0


def add_admin(username, name, role):
    if role not in ROLES:
        print("\n  Role must be one of: %s\n" % ", ".join(ROLES))
        return 1
    db.init(verbose=False)
    if db.query_one("SELECT username FROM admin_users WHERE username = ?", (username,)):
        print("\n  '%s' already exists.\n" % username)
        return 1

    first = getpass.getpass("  Password for %s: " % username)
    again = getpass.getpass("  Type it again: ")
    if first != again:
        print("\n  Those did not match. Nothing was created.\n")
        return 1

    digest, salt = security.hash_password(first)
    db.execute(
        "INSERT INTO admin_users (username, name, role, password_hash, password_salt, created_at)"
        " VALUES (?,?,?,?,?,?)",
        (username, name, role, digest, salt, db.now()),
    )
    db.audit("manage.py", "create", "admin_user", username, after={"name": name, "role": role})
    print("\n  Created %s (%s).\n" % (username, role))
    return 0


def reset_demo():
    """Clear the visitor data but keep the catalogue and the staff accounts."""
    db.init(verbose=False)
    for table in ("saved_schemes", "tracker", "profiles", "sessions", "match_runs", "users"):
        db.execute("DELETE FROM %s" % table)
    db.execute("UPDATE schemes SET active = 1")
    print("\n  Visitor data cleared. Scheme records, staff accounts and the audit log are untouched.")
    print("  To wipe everything and reseed instead: python backend/server.py --reset\n")


def stats():
    db.init(verbose=False)
    pairs = [
        ("scheme records", "SELECT COUNT(*) c FROM schemes"),
        ("  published", "SELECT COUNT(*) c FROM schemes WHERE active = 1"),
        ("offices", "SELECT COUNT(*) c FROM partners"),
        ("sessions", "SELECT COUNT(*) c FROM sessions"),
        ("registered users", "SELECT COUNT(*) c FROM users"),
        ("profiles", "SELECT COUNT(*) c FROM profiles"),
        ("matches run", "SELECT COUNT(*) c FROM match_runs"),
        ("saved schemes", "SELECT COUNT(*) c FROM saved_schemes"),
        ("audit entries", "SELECT COUNT(*) c FROM audit_log"),
    ]
    print("\n  %s" % db.DB_PATH)
    print("  " + "-" * 42)
    for label, sql in pairs:
        print("  %-20s %s" % (label, db.query_one(sql)["c"]))
    print("")


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 0

    command = args[0]
    if command == "list-admins":
        return list_admins()
    if command == "set-admin-password" and len(args) == 2:
        return set_password(args[1])
    if command == "add-admin" and len(args) == 4:
        return add_admin(args[1], args[2], args[3])
    if command == "reset-demo":
        return reset_demo()
    if command == "stats":
        return stats()

    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main() or 0)
