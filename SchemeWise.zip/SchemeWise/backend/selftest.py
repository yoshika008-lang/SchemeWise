"""
SchemeWise — self test.

    python backend/selftest.py

Runs the whole backend end to end without a browser: seeds the database,
matches the demo applicant, checks the loan maths, ranks offices, exercises
admin sign-in and the audit trail, and confirms the assistant answers with no
API key present. Run this before a demo — if it prints all green, the product
works.
"""

import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import db                                        # noqa: E402
import security                                  # noqa: E402
from engine.matcher import run_engine, clean_profile, subsidy_for   # noqa: E402
from engine.finance import compute_finance       # noqa: E402
from engine.geo import route_partners            # noqa: E402
from engine.catalogue import RULES, RULE_VERSION  # noqa: E402

PASSED = []
FAILED = []


def check(name, condition, detail=""):
    if condition:
        PASSED.append(name)
        print("  [ok]   %-46s %s" % (name, detail))
    else:
        FAILED.append(name)
        print("  [FAIL] %-46s %s" % (name, detail))


DEMO = {
    "age": 26, "state": "Tamil Nadu", "district": "Coimbatore", "city": "Coimbatore",
    "income": 300000, "employment": "unemployed", "education": "degree",
    "requirement": "start_business", "sector": "food_processing", "stage": "new",
    "projectCost": 800000, "amountNeeded": 720000, "experienceYears": 0,
    "category": "unspecified", "gender": "unspecified", "disability": "unspecified",
    "residency3": "yes", "firstGen": "yes", "loanStatus": "none",
}

SC_WOMAN = dict(DEMO, category="sc", gender="female", projectCost=1500000, amountNeeded=1400000)
STUDENT = dict(DEMO, requirement="education", projectCost=600000, amountNeeded=600000,
               sector="", income=400000)


def main():
    print("\n  SchemeWise self test")
    print("  " + "=" * 62)

    # -- database ------------------------------------------------------------
    print("\n  Database")
    db.init(verbose=False)
    schemes = db.all_schemes()
    check("24 scheme records seeded", len(schemes) == 24, "%d found" % len(schemes))
    check("office directory seeded", len(db.all_partners()) >= 12, "%d offices" % len(db.all_partners()))
    check("districts seeded", len(db.all_districts()) == 5, "%d states" % len(db.all_districts()))
    check("every record has a rule set", all(s["id"] in RULES for s in schemes),
          "rule version %s" % RULE_VERSION)

    # -- the engine ----------------------------------------------------------
    print("\n  Eligibility engine")
    result = run_engine(schemes, DEMO)
    total = len(result["eligible"]) + len(result["verify"]) + len(result["ineligible"])
    check("every scheme is classified", total == len(schemes),
          "%d eligible / %d verify / %d not" % (len(result["eligible"]),
                                                len(result["verify"]), len(result["ineligible"])))
    check("demo applicant has confirmed matches", len(result["eligible"]) > 0,
          "top: %s" % (result["eligible"][0]["scheme"]["name"][:34] if result["eligible"] else "—"))
    check("results are ordered by score",
          all(result["eligible"][i]["score"] >= result["eligible"][i + 1]["score"]
              for i in range(len(result["eligible"]) - 1)))
    check("every verdict carries its reasons",
          all(len(e["results"]) > 0 and all(r["note"] for r in e["results"]) for e in result["all"]))

    # The rule that matters most: an unanswered question is never a pass.
    vague = dict(DEMO)
    for field in ("category", "education", "stage", "loanStatus", "firstGen", "residency3"):
        vague[field] = "unspecified"
    vague_result = run_engine(schemes, vague)
    check("unanswered questions never become matches",
          len(vague_result["eligible"]) <= len(result["eligible"]),
          "%d confirmed vs %d when fully answered"
          % (len(vague_result["eligible"]), len(result["eligible"])))
    check("unanswered questions produce 'needs verification'",
          len(vague_result["verify"]) >= len(result["verify"]),
          "%d need checking" % len(vague_result["verify"]))

    # Statutory reservations must actually bite.
    general = dict(DEMO, category="oc", gender="male")
    general_ids = [e["scheme"]["id"] for e in run_engine(schemes, general)["eligible"]]
    check("SC-reserved schemes excluded for a general applicant",
          "nsfdc_term" not in general_ids and "tahdco_se" not in general_ids)
    sc_ids = [e["scheme"]["id"] for e in run_engine(schemes, SC_WOMAN)["eligible"]]
    check("Stand-Up India opens for an SC woman applicant", "standup" in sc_ids)

    student_result = run_engine(schemes, STUDENT)
    surfaced = student_result["eligible"] + student_result["verify"]
    # Matching is on funded PURPOSE, not on the label a scheme carries. NMDFC and
    # NDFDC are typed "Business" but both run an education loan variant, so they
    # belong in an education answer and a type filter would have hidden them.
    check("every surfaced scheme funds education",
          len(surfaced) > 0 and all("education" in e["scheme"]["purposes"] for e in surfaced),
          "%d surfaced: %s" % (len(surfaced), ", ".join(e["scheme"]["id"] for e in surfaced)))
    # Every education programme carries a mandatory check nobody can confirm from
    # a form — the institution must be on a notified list, or a caste certificate
    # must be produced. So they land in "verify", never "confirmed". That is the
    # engine refusing to promise something it cannot check.
    check("education schemes stay in 'needs verification'",
          len(student_result["eligible"]) == 0 and len(student_result["verify"]) > 0,
          "%d awaiting proof" % len(student_result["verify"]))

    # -- money ---------------------------------------------------------------
    print("\n  Finance")
    fin = compute_finance(project_cost=800000, rate=11, years=7,
                          moratorium_months=6, subsidy_amount=120000, contribution_pct=10)
    check("contribution is 10% of cost", fin["contribution"] == 80000, "₹%d" % fin["contribution"])
    check("loan = cost − contribution − subsidy", fin["loan"] == 600000, "₹%d" % fin["loan"])
    check("instalment is plausible", 9000 < fin["emi"] < 13000, "₹%.0f/month" % fin["emi"])
    check("moratorium interest is reported", fin["morInterest"] > 0, "₹%.0f" % fin["morInterest"])
    check("balance amortises to zero", fin["schedule"][-1]["balance"] == 0)
    check("zero-interest loan does not divide by zero",
          compute_finance(120000, 0, 2, 0, 0, 0)["emi"] == 5000.0)

    subsidy = subsidy_for(db.get_scheme("pmegp"), SC_WOMAN)
    check("PMEGP special-category rate applied", subsidy["pct"] == 25, "%d%%" % subsidy["pct"])

    # -- offices -------------------------------------------------------------
    print("\n  Partner routing")
    ranked = route_partners(db.all_partners(), [11.0168, 76.9558], "pmegp")
    check("offices ranked", len(ranked) > 0, "%d offices" % len(ranked))
    check("an office that handles the scheme ranks first", ranked[0]["handles"],
          ranked[0]["p"]["name"][:40])
    check("distance is computed", ranked[0]["dist"] is not None and ranked[0]["dist"] < 60,
          "%.1f km" % ranked[0]["dist"])

    # -- security ------------------------------------------------------------
    print("\n  Security")
    digest, salt = security.hash_password("scheme@2025")
    check("correct password verifies", security.verify_password("scheme@2025", digest, salt))
    check("wrong password rejected", not security.verify_password("wrong", digest, salt))
    check("password is not stored in plain text", "scheme@2025" not in digest)

    token = security.issue_token({"sub": "admin", "role": "super_admin"})
    check("valid token reads back", (security.read_token(token) or {}).get("role") == "super_admin")
    tampered = token[:-6] + ("aaaaaa" if not token.endswith("aaaaaa") else "bbbbbb")
    check("tampered token is rejected", security.read_token(tampered) is None)
    expired = security.issue_token({"sub": "x", "role": "citizen"}, ttl_seconds=-10)
    check("expired token is rejected", security.read_token(expired) is None)

    admin_row = db.query_one("SELECT * FROM admin_users WHERE username = 'admin'")
    check("admin account exists with a hashed password",
          admin_row is not None and len(admin_row["password_hash"]) == 64)

    # -- input handling ------------------------------------------------------
    print("\n  Input validation")
    hostile = clean_profile({
        "age": 9999, "income": -5000, "state": "<script>alert(1)</script>",
        "isAdmin": True, "password": "x", "projectCost": "800000",
    })
    check("out-of-range age is clamped", hostile["age"] == 110, "-> %s" % hostile["age"])
    check("negative income is clamped", hostile["income"] == 0)
    check("unknown fields are dropped", "isAdmin" not in hostile and "password" not in hostile)
    check("numeric strings are coerced", hostile["projectCost"] == 800000)

    # -- assistant -----------------------------------------------------------
    print("\n  Assistant")
    from routes.ai_routes import engine_answer, build_grounding
    had_key = os.environ.pop("GEMINI_API_KEY", None)
    answers = {
        "documents": engine_answer("what documents do I need?", DEMO),
        "emi": engine_answer("what will my EMI be?", DEMO),
        "where": engine_answer("where do I apply?", DEMO),
        "improve": engine_answer("how can I improve my eligibility?", DEMO),
        "summary": engine_answer("what do I qualify for?", DEMO),
    }
    if had_key:
        os.environ["GEMINI_API_KEY"] = had_key
    for name, text in answers.items():
        check("assistant answers '%s' with no API key" % name, len(text) > 40,
              text.split("\n")[0][:40] + "…")

    grounding = build_grounding(DEMO)
    check("assistant context is built from the engine",
          "ENGINE VERDICT" in grounding and RULE_VERSION in grounding,
          "%d characters of grounded facts" % len(grounding))

    # -- audit ---------------------------------------------------------------
    print("\n  Audit trail")
    before_count = db.query_one("SELECT COUNT(*) c FROM audit_log")["c"]
    db.audit("selftest", "update", "scheme", "pmegp",
             before={"maxFinancing": 5000000}, after={"maxFinancing": 5000000}, ip="127.0.0.1")
    after_count = db.query_one("SELECT COUNT(*) c FROM audit_log")["c"]
    check("a change writes an audit row", after_count == before_count + 1,
          "%d entries" % after_count)
    latest = db.query_one("SELECT * FROM audit_log ORDER BY id DESC LIMIT 1")
    check("audit row records who, what and when",
          latest["actor"] == "selftest" and latest["entity_id"] == "pmegp" and latest["at"])

    # -- result --------------------------------------------------------------
    print("\n  " + "=" * 62)
    if FAILED:
        print("  %d passed, %d FAILED" % (len(PASSED), len(FAILED)))
        for name in FAILED:
            print("     - %s" % name)
        print("")
        return 1
    print("  All %d checks passed. The backend is working.\n" % len(PASSED))
    return 0


if __name__ == "__main__":
    sys.exit(main())
