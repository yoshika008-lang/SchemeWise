"""
SchemeWise — administration.

This is the governance half of the product, and it is the half that turns a
hackathon demo into something a department could actually run.

Three properties, all enforced here and not in the browser:

  AUTHENTICATED  every route calls require_admin. The browser can hide a
                 button; only the server can refuse the request.

  AUDITED        every change writes a row to audit_log with the username, the
                 timestamp, the IP, and the exact before/after values. The table
                 is append-only — there is no route in this entire API that
                 updates or deletes an audit row.

  BOUNDED        an administrator may edit the RECORD (a ceiling, a rate, a
                 document list, a verification date). An administrator may not
                 edit the RULES, because those are legal tests and they live in
                 version control. Editing a record also resets its verification
                 date, so a changed figure cannot quietly keep an old stamp.
"""

import json

import db
import security
from app import HttpError
from routes._helpers import require_admin

# Only these columns can ever be written through the API. Anything else in the
# request body is ignored — an allowlist, not a blocklist.
EDITABLE = {
    "short":            ("short", str),
    "agency":           ("agency", str),
    "beneficiaries":    ("beneficiaries", str),
    "subsidyText":      ("subsidy_text", str),
    "applyText":        ("apply_text", str),
    "official":         ("official", str),
    "helpline":         ("helpline", str),
    "maxFinancing":     ("max_financing", int),
    "financingPct":     ("financing_pct", int),
    "projectMin":       ("project_min", int),
    "projectMax":       ("project_max", int),
    "incomeLimit":      ("income_limit", int),
    "repaymentYears":   ("repayment_years", int),
    "moratoriumMonths": ("moratorium_months", int),
    "rateMin":          ("rate_min", float),
    "rateMax":          ("rate_max", float),
    "lastVerified":     ("last_verified", str),
    "confidence":       ("confidence", str),
    "documents":        ("documents", list),
}

BOUNDS = {
    "max_financing": (0, 1000000000),
    "financing_pct": (0, 100),
    "project_min": (0, 1000000000),
    "project_max": (0, 1000000000),
    "income_limit": (0, 100000000),
    "repayment_years": (0, 30),
    "moratorium_months": (0, 60),
    "rate_min": (0, 36),
    "rate_max": (0, 36),
}


def register(app):

    # ------------------------------------------------------------------------
    # Scheme records
    # ------------------------------------------------------------------------

    @app.get("/api/admin/schemes")
    def list_all(req):
        require_admin(req)
        schemes = db.all_schemes(include_inactive=True)
        from engine.catalogue import RULES, RULE_VERSION
        for s in schemes:
            # Shown in the admin table so staff can see a record is governed by
            # published logic they cannot reach from this screen.
            s["ruleCount"] = len(RULES.get(s["id"], []))
        return {"schemes": schemes, "total": len(schemes), "ruleVersion": RULE_VERSION}

    @app.patch("/api/admin/schemes/:id")
    def update_scheme(req):
        admin = require_admin(req)
        scheme_id = req.params["id"]
        before = db.get_scheme(scheme_id)
        if not before:
            raise HttpError(404, "No scheme with id '%s'" % scheme_id)

        body = req.json
        updates = {}
        changed = {}

        for api_field, (column, kind) in EDITABLE.items():
            if api_field not in body:
                continue
            value = body[api_field]

            if kind is int or kind is float:
                if value in ("", None):
                    value = None
                else:
                    try:
                        value = kind(value)
                    except (TypeError, ValueError):
                        raise HttpError(400, "%s must be a number" % api_field)
                    low, high = BOUNDS.get(column, (0, 10 ** 12))
                    if not (low <= value <= high):
                        raise HttpError(400, "%s must be between %s and %s" % (api_field, low, high))
                    if kind is int:
                        value = int(value)

            elif kind is list:
                if not isinstance(value, list):
                    raise HttpError(400, "%s must be a list" % api_field)
                value = json.dumps([str(x).strip()[:400] for x in value[:40] if str(x).strip()])

            else:
                value = security.need(body, api_field, str, max_length=4000,
                                      required=api_field not in ("helpline",))

            updates[column] = value
            changed[api_field] = value

        if not updates:
            raise HttpError(400, "Nothing to update. Editable fields: %s"
                            % ", ".join(sorted(EDITABLE)))

        if "rate_min" in updates and "rate_max" in updates:
            if updates["rate_min"] > updates["rate_max"]:
                raise HttpError(400, "The lower interest bound cannot exceed the upper bound")

        # A changed figure must not keep an old verification stamp.
        if "last_verified" not in updates:
            updates["last_verified"] = db.now()[:10]
            changed["lastVerified"] = updates["last_verified"]
        updates["updated_at"] = db.now()

        assignments = ", ".join("%s = ?" % c for c in updates)
        db.execute("UPDATE schemes SET %s WHERE id = ?" % assignments,
                   tuple(updates.values()) + (scheme_id,))

        after = db.get_scheme(scheme_id)
        db.audit(admin["username"], "update", "scheme", scheme_id,
                 before={k: before.get(k) for k in changed},
                 after=changed, ip=req.ip)

        return {"scheme": after, "changed": sorted(changed), "auditWritten": True}

    @app.post("/api/admin/schemes/:id/toggle")
    def toggle_scheme(req):
        admin = require_admin(req)
        scheme = db.get_scheme(req.params["id"])
        if not scheme:
            raise HttpError(404, "No scheme with id '%s'" % req.params["id"])

        new_state = 0 if scheme["active"] else 1
        db.execute("UPDATE schemes SET active = ?, updated_at = ? WHERE id = ?",
                   (new_state, db.now(), scheme["id"]))
        db.audit(admin["username"], "enable" if new_state else "disable", "scheme", scheme["id"],
                 before={"active": scheme["active"]}, after={"active": bool(new_state)}, ip=req.ip)

        return {"schemeId": scheme["id"], "active": bool(new_state)}

    # ------------------------------------------------------------------------
    # Audit trail
    # ------------------------------------------------------------------------

    @app.get("/api/admin/audit")
    def audit_log(req):
        require_admin(req)
        try:
            limit = min(200, max(1, int(req.q("limit", 50))))
        except ValueError:
            limit = 50

        rows = db.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))
        entries = []
        for r in rows:
            entries.append({
                "id": r["id"],
                "actor": r["actor"],
                "action": r["action"],
                "entity": r["entity"],
                "entityId": r["entity_id"],
                "before": json.loads(r["before"]) if r["before"] else None,
                "after": json.loads(r["after"]) if r["after"] else None,
                "ip": r["ip"],
                "at": r["at"],
            })
        total = db.query_one("SELECT COUNT(*) c FROM audit_log")["c"]
        return {"entries": entries, "total": total, "appendOnly": True}

    # ------------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------------

    @app.get("/api/admin/stats")
    def stats(req):
        """
        Aggregate demand. Every figure here is a COUNT over anonymised rows —
        there is no query in this endpoint that returns anything about one
        identifiable person.
        """
        require_admin(req)

        def rows_to_list(sql, args=()):
            return [dict(r) for r in db.query(sql, args)]

        stale = db.query_one(
            "SELECT COUNT(*) c FROM schemes WHERE date(last_verified) < date('now', '-12 months')"
        )["c"]

        return {
            "catalogue": {
                "total": db.query_one("SELECT COUNT(*) c FROM schemes")["c"],
                "active": db.query_one("SELECT COUNT(*) c FROM schemes WHERE active = 1")["c"],
                "staleVerification": stale,
                "byType": rows_to_list(
                    "SELECT type, COUNT(*) count FROM schemes GROUP BY type ORDER BY count DESC"),
            },
            "usage": {
                "sessions": db.query_one("SELECT COUNT(*) c FROM sessions")["c"],
                "registeredUsers": db.query_one("SELECT COUNT(*) c FROM users")["c"],
                "profilesCompleted": db.query_one("SELECT COUNT(*) c FROM profiles")["c"],
                "matchesRun": db.query_one("SELECT COUNT(*) c FROM match_runs")["c"],
                "schemesSaved": db.query_one("SELECT COUNT(*) c FROM saved_schemes")["c"],
            },
            "demand": {
                "topRequirements": rows_to_list(
                    "SELECT requirement, COUNT(*) count FROM match_runs"
                    " WHERE requirement IS NOT NULL GROUP BY requirement"
                    " ORDER BY count DESC LIMIT 8"),
                "topDistricts": rows_to_list(
                    "SELECT state, district, COUNT(*) count FROM match_runs"
                    " WHERE district IS NOT NULL GROUP BY state, district"
                    " ORDER BY count DESC LIMIT 8"),
                "mostRecommended": rows_to_list(
                    "SELECT top_scheme scheme, COUNT(*) count FROM match_runs"
                    " WHERE top_scheme IS NOT NULL GROUP BY top_scheme"
                    " ORDER BY count DESC LIMIT 8"),
                "averageMatches": (db.query_one(
                    "SELECT ROUND(AVG(eligible_count), 2) a FROM match_runs")["a"] or 0),
                "zeroMatchRuns": db.query_one(
                    "SELECT COUNT(*) c FROM match_runs WHERE eligible_count = 0")["c"],
            },
            "governance": {
                "auditEntries": db.query_one("SELECT COUNT(*) c FROM audit_log")["c"],
                "lastChange": (db.query_one(
                    "SELECT at FROM audit_log WHERE action IN ('update','enable','disable')"
                    " ORDER BY id DESC LIMIT 1") or {"at": None})["at"],
            },
        }
