"""
SchemeWise — the calculator endpoint.

The browser sends five numbers and renders the answer. It does no arithmetic.
Open the Network tab during a demo, drag the project-cost slider, and every
movement is a POST with a JSON response — which is the fastest way to show
somebody that the calculator is not a toy running in the page.
"""

import db
import security
from app import HttpError
from engine.finance import quote
from engine.matcher import subsidy_for, clean_profile


def register(app):

    @app.post("/api/finance/quote")
    def finance_quote(req):
        body = req.json

        scheme_id = security.need(body, "schemeId", str, max_length=40)
        scheme = db.get_scheme(scheme_id)
        if not scheme:
            raise HttpError(404, "No scheme with id '%s'" % scheme_id)
        if not scheme["maxFinancing"]:
            raise HttpError(400, "%s does not provide financing, so there is nothing to calculate"
                            % scheme["name"])

        cost = security.need(body, "cost", int, minimum=1000, maximum=1000000000)
        rate = security.need(body, "rate", float, minimum=0, maximum=36)
        years = security.need(body, "years", int, minimum=1, maximum=30)
        moratorium = security.optional(body, "moratoriumMonths", int, minimum=0, maximum=60, default=0)
        contribution = security.optional(body, "contributionPct", float, minimum=0, maximum=90, default=10)

        profile = clean_profile(body.get("profile") or {})
        profile["projectCost"] = min(cost, scheme["projectMax"] or cost)

        subsidy = subsidy_for(scheme, profile)
        answer = quote(scheme, profile, cost, rate, years, moratorium, contribution, subsidy)
        answer["computedOn"] = "server"
        return answer

    @app.post("/api/finance/compare")
    def finance_compare(req):
        """
        The same project costed against several schemes at once, cheapest total
        repayment first. This is the question people actually have — "which of
        these is cheapest for me" — and it is a server-side join across records
        rather than something the page could work out on its own.
        """
        body = req.json
        cost = security.need(body, "cost", int, minimum=1000, maximum=1000000000)
        years = security.optional(body, "years", int, minimum=1, maximum=30, default=7)
        contribution = security.optional(body, "contributionPct", float, minimum=0, maximum=90, default=10)
        profile = clean_profile(body.get("profile") or {})

        ids = body.get("schemeIds")
        if ids and not isinstance(ids, list):
            raise HttpError(400, "schemeIds must be a list")

        schemes = db.all_schemes()
        if ids:
            wanted = set(str(i) for i in ids[:20])
            schemes = [s for s in schemes if s["id"] in wanted]
        schemes = [s for s in schemes if s["maxFinancing"] > 0]

        rows = []
        for scheme in schemes:
            p = dict(profile)
            p["projectCost"] = min(cost, scheme["projectMax"] or cost)
            rate = scheme["rate"]["min"] if scheme["rate"]["fixed"] else \
                round((scheme["rate"]["min"] + scheme["rate"]["max"]) / 2 * 4) / 4
            subsidy = subsidy_for(scheme, p)
            answer = quote(scheme, p, cost, rate,
                           years or scheme["repaymentYears"] or 7,
                           scheme["moratoriumMonths"], contribution, subsidy)
            answer["rateUsed"] = rate
            rows.append(answer)

        rows.sort(key=lambda r: r["totalRepayment"])
        return {"cost": cost, "compared": len(rows), "options": rows}
