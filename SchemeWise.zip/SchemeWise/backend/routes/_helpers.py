"""
SchemeWise — request helpers shared by every route module.

The two functions that matter are require_session and require_admin. They are
the gate. A route that does not call one of them is public, on purpose; a route
that does cannot be reached with a missing, expired, or edited token.
"""

import db
import security
from app import HttpError


# ----------------------------------------------------------------------------
# Middleware — runs before every route
# ----------------------------------------------------------------------------

def attach_identity(req):
    """
    Read the Authorization header, verify the signature, and hang whatever it
    proves onto the request. Nothing here trusts the client's word for who it
    is: the token's signature is checked against the server secret first, and
    for citizens the session is then confirmed to still exist in the database.
    """
    token = req.bearer()
    if not token:
        return None

    claims = security.read_token(token)
    if not claims:
        return None  # expired or tampered with -> simply not signed in

    if claims.get("role") == "citizen":
        row = db.query_one("SELECT * FROM sessions WHERE token = ?", (claims.get("sub"),))
        if row:
            req.session = dict(row)
            db.execute("UPDATE sessions SET last_seen = ? WHERE token = ?",
                       (db.now(), row["token"]))
    elif claims.get("role") in ("super_admin", "verification_officer"):
        row = db.query_one("SELECT username, name, role FROM admin_users WHERE username = ?",
                           (claims.get("sub"),))
        if row:
            req.admin = dict(row)
            req.admin["loginAt"] = claims.get("loginAt")

    return None


def rate_limit(req):
    """
    A budget per IP. Writes and AI calls are metered harder than reads because
    they cost more to serve.
    """
    path = req.path
    if req.method == "OPTIONS":
        return None

    if path.startswith("/api/ai"):
        security.limiter.check("ai:" + req.ip, capacity=12, refill_per_second=0.1)
    elif path.endswith("/login") or path.endswith("/register"):
        # Slow down credential guessing without locking a real person out.
        security.limiter.check("auth:" + req.ip, capacity=8, refill_per_second=0.05)
    elif req.method in ("POST", "PUT", "PATCH", "DELETE"):
        security.limiter.check("write:" + req.ip, capacity=90, refill_per_second=2.0)
    else:
        security.limiter.check("read:" + req.ip, capacity=240, refill_per_second=10.0)

    return None


# ----------------------------------------------------------------------------
# Guards — call these at the top of a protected route
# ----------------------------------------------------------------------------

def require_session(req):
    """Any visitor, signed in or anonymous, who holds a valid session token."""
    if not req.session:
        raise HttpError(401, "No active session. Call POST /api/session first.")
    return req.session


def require_admin(req, role=None):
    """Staff only. Pass role='super_admin' for the operations only they may do."""
    if not req.admin:
        raise HttpError(401, "Administrator sign-in required")
    if role and req.admin["role"] != role:
        raise HttpError(403, "Your role (%s) cannot perform this action" % req.admin["role"])
    return req.admin
