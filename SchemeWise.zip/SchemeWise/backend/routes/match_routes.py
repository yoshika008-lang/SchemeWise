"""
SchemeWise — the matching endpoint.

POST /api/match is the endpoint to open in front of a judge. The browser sends
answers; the server sends back a verdict, a score broken down by area, and the
sentence behind every single rule that was checked. Nothing about that verdict
can be changed from the browser.

Each call also writes one anonymised row to match_runs: state, district,
requirement, category, and how many schemes landed in each bucket. No name, no
phone, no income figure. That is enough to answer "which districts are asking
for what" — which is the question a government department actually wants
answered — without building a file on anybody.
"""

import db
from engine.matcher import run_engine, clean_profile, subsidy_for
from app import HttpError


def _record_run(req, profile, result):
    top = result["eligible"][0]["scheme"]["id"] if result["eligible"] else None
    db.execute(
        """INSERT INTO match_runs
           (session_token, state, district, requirement, category,
            eligible_count, verify_count, ineligible_count, top_scheme, at)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (
            req.session["token"] if req.session else None,
            profile.get("state"),
            profile.get("district"),
            profile.get("requirement"),
            profile.get("category"),
            len(result["eligible"]),
            len(result["verify"]),
            len(result["ineligible"]),
            top,
            db.now(),
        ),
    )


def register(app):

    @app.post("/api/match")
    def match(req):
        """
        Body: {"profile": {...}}
        Returns eligible / verify / ineligible, each a full evaluation.
        """
        raw = req.json.get("profile")
        if not isinstance(raw, dict):
            raise HttpError(400, "Send a profile object: {\"profile\": { ... }}")

        profile = clean_profile(raw)
        if not profile:
            raise HttpError(400, "The profile had no usable fields")

        schemes = db.all_schemes(include_inactive=False)
        result = run_engine(schemes, profile)

        try:
            _record_run(req, profile, result)
        except Exception:
            pass  # analytics must never be able to break a citizen's answer

        return {
            "profile": profile,
            "ruleVersion": result["ruleVersion"],
            "counts": {
                "eligible": len(result["eligible"]),
                "verify": len(result["verify"]),
                "ineligible": len(result["ineligible"]),
                "evaluated": len(result["all"]),
            },
            "eligible": result["eligible"],
            "verify": result["verify"],
            "ineligible": result["ineligible"],
            "all": result["all"],
        }

    @app.post("/api/match/subsidy")
    def subsidy(req):
        """What one scheme is worth to this applicant, in rupees."""
        scheme_id = req.json.get("schemeId")
        scheme = db.get_scheme(scheme_id)
        if not scheme:
            raise HttpError(404, "No scheme with id '%s'" % scheme_id)
        profile = clean_profile(req.json.get("profile") or {})
        return {"schemeId": scheme_id, "subsidy": subsidy_for(scheme, profile)}
