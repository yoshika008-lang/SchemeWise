"""
SchemeWise — API routes.

Each module registers its own endpoints against the shared app. Keeping them
separate means you can point at one file and say "that is everything the admin
screen can do", which is exactly the question a reviewer asks.
"""

from routes import (
    auth_routes,
    scheme_routes,
    match_routes,
    profile_routes,
    finance_routes,
    partner_routes,
    ai_routes,
    admin_routes,
    meta_routes,
)

MODULES = [
    meta_routes,
    auth_routes,
    scheme_routes,
    match_routes,
    profile_routes,
    finance_routes,
    partner_routes,
    ai_routes,
    admin_routes,
]


def register_all(app):
    for module in MODULES:
        module.register(app)
    return len(app.routes)
