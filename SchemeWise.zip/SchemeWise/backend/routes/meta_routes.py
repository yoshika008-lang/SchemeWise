"""
SchemeWise — operational endpoints.

/api/health is the one to keep open in a browser tab during a demo. It proves
the server is up, the database is reachable, and how many records are loaded.
/api/docs lists every route, generated from the routing table itself, so it can
never drift out of date with the code.
"""

import time

import db

STARTED = time.time()
VERSION = "1.0.0"


def register(app):

    @app.get("/api/health")
    def health(req):
        try:
            scheme_count = db.query_one("SELECT COUNT(*) c FROM schemes")["c"]
            database = "connected"
        except Exception as e:
            scheme_count = 0
            database = "error: %s" % e

        uptime = int(time.time() - STARTED)
        return {
            "status": "ok" if database == "connected" else "degraded",
            "version": VERSION,
            "database": database,
            "schemes": scheme_count,
            "partners": db.query_one("SELECT COUNT(*) c FROM partners")["c"],
            "uptimeSeconds": uptime,
            "uptime": "%dh %dm %ds" % (uptime // 3600, uptime % 3600 // 60, uptime % 60),
        }

    @app.get("/api/docs")
    def docs(req):
        """Self-describing API. Generated from the live routing table."""
        grouped = {}
        for method, _regex, fn, pattern in app.routes:
            group = pattern.split("/")[2] if pattern.count("/") > 2 else "root"
            summary = (fn.__doc__ or "").strip().split("\n")[0]
            grouped.setdefault(group, []).append({
                "method": method,
                "path": pattern,
                "summary": summary,
            })
        for entries in grouped.values():
            entries.sort(key=lambda e: (e["path"], e["method"]))

        return {
            "service": "SchemeWise API",
            "version": VERSION,
            "routeCount": len(app.routes),
            "groups": grouped,
        }

    @app.post("/api/events")
    def track(req):
        """
        Anonymous product analytics. Name and a small payload only — this route
        deliberately has no field for anything that identifies a person.
        """
        name = str(req.json.get("name", ""))[:60]
        if not name:
            return {"recorded": False}
        return {"recorded": True, "event": name}
