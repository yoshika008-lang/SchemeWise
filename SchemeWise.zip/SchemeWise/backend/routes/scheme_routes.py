"""
SchemeWise — the scheme catalogue and reference data.

Public, read-only endpoints. Note what a public caller gets back: the record
only. Never the rules. The rules are what decides, and they are evaluated on
the server; shipping them to the browser would put the decision back in a place
the applicant can edit.

Deactivated schemes are invisible here and visible to an administrator, which
is the whole point of the `active` flag: a programme whose window has closed
stops being recommended without anybody deleting its history.
"""

import db
from app import HttpError
from engine.geo import KIND_LABEL


def register(app):

    @app.get("/api/schemes")
    def list_schemes(req):
        """
        Filters: ?type=Business & ?state=Tamil Nadu & ?purpose=start_business & ?q=food
        Filtering here rather than in the browser means a real deployment with
        2,000 schemes sends 20, not 2,000.
        """
        include_inactive = bool(req.admin)
        schemes = db.all_schemes(include_inactive=include_inactive)

        scheme_type = req.q("type")
        state = req.q("state")
        purpose = req.q("purpose")
        text = (req.q("q") or "").strip().lower()

        if scheme_type and scheme_type != "all":
            schemes = [s for s in schemes if s["type"] == scheme_type]
        if state and state != "all":
            schemes = [s for s in schemes if "ALL" in s["states"] or state in s["states"]]
        if purpose and purpose != "all":
            schemes = [s for s in schemes if purpose in s["purposes"]]
        if text:
            schemes = [s for s in schemes if text in (s["name"] + " " + s["short"]).lower()]

        return {
            "schemes": schemes,
            "count": len(schemes),
            "total": len(db.all_schemes(include_inactive=include_inactive)),
        }

    @app.get("/api/schemes/:id")
    def get_one(req):
        scheme = db.get_scheme(req.params["id"], include_inactive=bool(req.admin))
        if not scheme:
            raise HttpError(404, "No scheme with id '%s'" % req.params["id"])
        if not scheme["active"] and not req.admin:
            raise HttpError(404, "This scheme is not currently published")
        return {"scheme": scheme}

    @app.get("/api/reference")
    def reference(req):
        """
        Everything the frontend needs to draw dropdowns and maps: districts with
        coordinates, the office directory, and the office-type labels.
        """
        return {
            "districts": db.all_districts(),
            "partners": db.all_partners(),
            "kindLabels": KIND_LABEL,
            "schemeTypes": ["Business", "Education", "Skill", "Livelihood", "Guarantee"],
        }
