"""
SchemeWise — identity.

Three kinds of caller, deliberately:

  anonymous visitor  gets a signed session token the moment the page loads, so
                     their profile, shortlist and checklist persist without
                     asking a first-time user for a phone number. Removing the
                     signup wall is an accessibility decision, not a shortcut.

  citizen account    phone + password, optional. Creating one CLAIMS the
                     anonymous session, so nothing the person already did is
                     lost when they decide to sign up.

  administrator      separate table, separate token role, scrypt-hashed
                     passwords. An administrator token is the only thing that
                     can change a scheme record.
"""

import db
import security
from app import HttpError
from routes._helpers import require_session, require_admin


def register(app):

    # ------------------------------------------------------------------------
    # Anonymous session
    # ------------------------------------------------------------------------

    @app.post("/api/session")
    def create_session(req):
        """Called once by the frontend on first load."""
        token = security.new_session_token()
        db.execute(
            "INSERT INTO sessions (token, user_id, created_at, last_seen, ip) VALUES (?,?,?,?,?)",
            (token, None, db.now(), db.now(), req.ip),
        )
        return {
            "token": security.issue_token({"sub": token, "role": "citizen"}),
            "sessionId": token[:8],
            "anonymous": True,
        }

    @app.get("/api/auth/me")
    def whoami(req):
        """What the server believes about the caller. Useful for the demo."""
        if req.admin:
            return {"kind": "admin", "admin": req.admin}
        if req.session:
            user = None
            if req.session.get("user_id"):
                row = db.query_one("SELECT id, phone, name FROM users WHERE id = ?",
                                   (req.session["user_id"],))
                user = dict(row) if row else None
            return {
                "kind": "citizen",
                "anonymous": user is None,
                "user": user,
                "sessionId": req.session["token"][:8],
                "createdAt": req.session["created_at"],
            }
        return {"kind": "anonymous", "signedIn": False}

    # ------------------------------------------------------------------------
    # Citizen accounts
    # ------------------------------------------------------------------------

    @app.post("/api/auth/register")
    def register_citizen(req):
        session = require_session(req)
        body = req.json

        phone = security.need(body, "phone", str, max_length=15)
        name = security.need(body, "name", str, max_length=80)
        password = security.need(body, "password", str, max_length=200)

        digits = "".join(c for c in phone if c.isdigit())
        if len(digits) != 10:
            raise HttpError(400, "Enter a 10-digit mobile number")

        if db.query_one("SELECT id FROM users WHERE phone = ?", (digits,)):
            raise HttpError(409, "An account already exists for this number")

        digest, salt = security.hash_password(password)
        cur = db.execute(
            "INSERT INTO users (phone, name, password_hash, password_salt, created_at) VALUES (?,?,?,?,?)",
            (digits, name, digest, salt, db.now()),
        )
        user_id = cur.lastrowid

        # Carry the anonymous work over instead of throwing it away.
        db.execute("UPDATE sessions SET user_id = ? WHERE token = ?", (user_id, session["token"]))
        db.execute("UPDATE profiles SET user_id = ? WHERE session_token = ?", (user_id, session["token"]))

        return {
            "user": {"id": user_id, "phone": digits, "name": name},
            "claimedSession": session["token"][:8],
        }, 201

    @app.post("/api/auth/login")
    def login_citizen(req):
        body = req.json
        phone = security.need(body, "phone", str, max_length=15)
        password = security.need(body, "password", str, max_length=200)
        digits = "".join(c for c in phone if c.isdigit())

        row = db.query_one("SELECT * FROM users WHERE phone = ?", (digits,))
        # Same message whether the number is unknown or the password is wrong:
        # a different message would tell an attacker which numbers are registered.
        if not row or not security.verify_password(password, row["password_hash"], row["password_salt"]):
            raise HttpError(401, "Incorrect mobile number or password")

        token = security.new_session_token()
        db.execute(
            "INSERT INTO sessions (token, user_id, created_at, last_seen, ip) VALUES (?,?,?,?,?)",
            (token, row["id"], db.now(), db.now(), req.ip),
        )
        return {
            "token": security.issue_token({"sub": token, "role": "citizen"}),
            "user": {"id": row["id"], "phone": row["phone"], "name": row["name"]},
        }

    # ------------------------------------------------------------------------
    # Administrators
    # ------------------------------------------------------------------------

    @app.post("/api/admin/login")
    def login_admin(req):
        body = req.json
        username = security.need(body, "username", str, max_length=40).lower()
        password = security.need(body, "password", str, max_length=200)

        row = db.query_one("SELECT * FROM admin_users WHERE lower(username) = ?", (username,))
        if not row or not security.verify_password(password, row["password_hash"], row["password_salt"]):
            db.audit(username, "login_failed", "admin_user", username, ip=req.ip)
            raise HttpError(401, "Incorrect username or password")

        login_at = db.now()
        db.execute("UPDATE admin_users SET last_login = ? WHERE username = ?", (login_at, row["username"]))
        db.audit(row["username"], "login", "admin_user", row["username"], ip=req.ip)

        return {
            "token": security.issue_token(
                {"sub": row["username"], "role": row["role"], "loginAt": login_at},
                ttl_seconds=60 * 60 * 4,
            ),
            "admin": {
                "user": row["username"],
                "name": row["name"],
                "role": row["role"],
                "loginAt": login_at,
            },
        }

    @app.get("/api/admin/me")
    def admin_me(req):
        return {"admin": require_admin(req)}

    @app.post("/api/admin/logout")
    def admin_logout(req):
        admin = require_admin(req)
        db.audit(admin["username"], "logout", "admin_user", admin["username"], ip=req.ip)
        return {"ok": True}
