"""
SchemeWise — a citizen's own data: profile, shortlist, document checklist.

Every route here is scoped to the caller's session token. There is no route
that takes a session id as a parameter, so there is no way to ask the server
for somebody else's profile: the only session the server will read is the one
the caller proved they hold.
"""

import json

import db
import security
from app import HttpError
from engine.matcher import clean_profile, run_engine
from routes._helpers import require_session


def register(app):

    # ------------------------------------------------------------------------
    # Profile
    # ------------------------------------------------------------------------

    @app.put("/api/profile")
    def save_profile(req):
        """
        Save the onboarding answers and return the fresh match in the same
        response — the browser needs both and this makes it one round trip.
        """
        session = require_session(req)
        profile = clean_profile(req.json.get("profile") or {})
        if not profile:
            raise HttpError(400, "The profile had no usable fields")

        payload = json.dumps(profile)
        existing = db.query_one("SELECT id FROM profiles WHERE session_token = ?", (session["token"],))
        if existing:
            db.execute("UPDATE profiles SET data = ?, updated_at = ? WHERE session_token = ?",
                       (payload, db.now(), session["token"]))
        else:
            db.execute(
                "INSERT INTO profiles (session_token, user_id, data, created_at, updated_at)"
                " VALUES (?,?,?,?,?)",
                (session["token"], session.get("user_id"), payload, db.now(), db.now()),
            )

        result = run_engine(db.all_schemes(), profile)
        return {
            "profile": profile,
            "saved": True,
            "match": {
                "ruleVersion": result["ruleVersion"],
                "eligible": result["eligible"],
                "verify": result["verify"],
                "ineligible": result["ineligible"],
                "all": result["all"],
            },
        }

    @app.get("/api/profile")
    def get_profile(req):
        session = require_session(req)
        row = db.query_one("SELECT * FROM profiles WHERE session_token = ?", (session["token"],))
        if not row:
            return {"profile": None}
        return {"profile": json.loads(row["data"]), "updatedAt": row["updated_at"]}

    # ------------------------------------------------------------------------
    # Saved schemes
    # ------------------------------------------------------------------------

    @app.get("/api/saved")
    def list_saved(req):
        session = require_session(req)
        rows = db.query(
            "SELECT scheme_id FROM saved_schemes WHERE session_token = ? ORDER BY created_at",
            (session["token"],),
        )
        return {"saved": [r["scheme_id"] for r in rows]}

    @app.post("/api/saved/:schemeId")
    def toggle_saved(req):
        session = require_session(req)
        scheme_id = req.params["schemeId"]
        if not db.get_scheme(scheme_id):
            raise HttpError(404, "No scheme with id '%s'" % scheme_id)

        existing = db.query_one(
            "SELECT 1 FROM saved_schemes WHERE session_token = ? AND scheme_id = ?",
            (session["token"], scheme_id),
        )
        if existing:
            db.execute("DELETE FROM saved_schemes WHERE session_token = ? AND scheme_id = ?",
                       (session["token"], scheme_id))
            saved = False
        else:
            db.execute(
                "INSERT INTO saved_schemes (session_token, scheme_id, created_at) VALUES (?,?,?)",
                (session["token"], scheme_id, db.now()),
            )
            saved = True

        rows = db.query("SELECT scheme_id FROM saved_schemes WHERE session_token = ?",
                        (session["token"],))
        return {"schemeId": scheme_id, "saved": saved, "all": [r["scheme_id"] for r in rows]}

    # ------------------------------------------------------------------------
    # Application tracker + document checklist
    # ------------------------------------------------------------------------

    @app.get("/api/tracker")
    def get_tracker(req):
        session = require_session(req)
        rows = db.query("SELECT * FROM tracker WHERE session_token = ?", (session["token"],))
        return {
            "tracker": {
                r["scheme_id"]: {"status": r["status"], "docs": json.loads(r["docs"])}
                for r in rows
            }
        }

    VALID_STAGES = ["not_started", "documents", "ready", "submitted", "review", "completed"]
    VALID_DOC_STATES = ["need", "ready", "na"]

    @app.put("/api/tracker/:schemeId")
    def update_tracker(req):
        session = require_session(req)
        scheme = db.get_scheme(req.params["schemeId"])
        if not scheme:
            raise HttpError(404, "No scheme with id '%s'" % req.params["schemeId"])

        body = req.json
        status = security.optional(body, "status", str, choices=VALID_STAGES, default=None)

        docs = body.get("docs")
        if docs is not None:
            if not isinstance(docs, dict):
                raise HttpError(400, "docs must be an object of {index: state}")
            cleaned = {}
            for key, value in list(docs.items())[:60]:
                if str(value) in VALID_DOC_STATES and str(key).isdigit():
                    if int(key) < len(scheme["documents"]):
                        cleaned[str(key)] = str(value)
            docs = cleaned

        existing = db.query_one(
            "SELECT * FROM tracker WHERE session_token = ? AND scheme_id = ?",
            (session["token"], req.params["schemeId"]),
        )
        if existing:
            new_status = status if status is not None else existing["status"]
            new_docs = docs if docs is not None else json.loads(existing["docs"])
            db.execute(
                "UPDATE tracker SET status = ?, docs = ?, updated_at = ?"
                " WHERE session_token = ? AND scheme_id = ?",
                (new_status, json.dumps(new_docs), db.now(),
                 session["token"], req.params["schemeId"]),
            )
        else:
            new_status = status or "not_started"
            new_docs = docs or {}
            db.execute(
                "INSERT INTO tracker (session_token, scheme_id, status, docs, updated_at)"
                " VALUES (?,?,?,?,?)",
                (session["token"], req.params["schemeId"], new_status,
                 json.dumps(new_docs), db.now()),
            )

        return {"schemeId": req.params["schemeId"], "status": new_status, "docs": new_docs}
