"""
SchemeWise — "where do I actually apply?"

The ranking lives on the server because it is a recommendation, not a drawing.
The browser gets an ordered list with the reasoning attached and draws pins
from it.
"""

import db
import security
from app import HttpError
from engine.geo import route_partners, KIND_LABEL


def _origin_from(body):
    """
    Prefer a real GPS fix, fall back to the district centroid, and say which
    one was used so the page can be honest about the distances it shows.
    """
    origin = body.get("origin")
    if isinstance(origin, list) and len(origin) == 2:
        try:
            lat, lng = float(origin[0]), float(origin[1])
            if -90 <= lat <= 90 and -180 <= lng <= 180:
                return [lat, lng], "device"
        except (TypeError, ValueError):
            pass

    state = body.get("state")
    district = body.get("district")
    if state and district:
        row = db.query_one("SELECT lat, lng FROM districts WHERE state = ? AND district = ?",
                           (state, district))
        if row:
            return [row["lat"], row["lng"]], "district"

    row = db.query_one("SELECT lat, lng FROM districts WHERE state = ? AND district = ?",
                       ("Tamil Nadu", "Coimbatore"))
    return ([row["lat"], row["lng"]] if row else None), "default"


def register(app):

    @app.post("/api/partners/route")
    def route(req):
        body = req.json
        scheme_id = body.get("schemeId")
        if scheme_id in ("all", "", None):
            scheme_id = None
        elif not db.get_scheme(scheme_id):
            raise HttpError(404, "No scheme with id '%s'" % scheme_id)

        kind = security.optional(body, "kind", str, max_length=30, default="all")
        if kind != "all" and kind not in KIND_LABEL:
            raise HttpError(400, "Unknown office type '%s'" % kind)

        origin, origin_kind = _origin_from(body)
        ranked = route_partners(db.all_partners(), origin, scheme_id, kind)

        return {
            "origin": origin,
            "originSource": origin_kind,
            "schemeId": scheme_id,
            "kind": kind,
            "results": ranked,
            "within40km": len([r for r in ranked if r["dist"] is not None and r["dist"] < 40]),
            "kindLabels": KIND_LABEL,
            "ranking": "50% handles this scheme, 25% office type, 25% distance",
        }

    @app.get("/api/partners")
    def list_partners(req):
        return {"partners": db.all_partners(), "kindLabels": KIND_LABEL}
