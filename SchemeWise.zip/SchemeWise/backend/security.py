"""
SchemeWise — security layer.

Three jobs:

  1. Passwords are never stored. We store a scrypt hash + a random salt.
     Even with the database file in hand you cannot read a password out of it.

  2. Tokens are signed, not guessed. A token is a small JSON payload plus an
     HMAC-SHA256 signature made with the server's secret. Change one character
     of the payload and the signature stops matching, so a user cannot promote
     themselves to admin by editing their own token.

  3. Nobody gets to hammer the server. A token bucket per IP per route family.

Everything here uses only the Python standard library (hashlib, hmac, secrets).
"""

import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
import time

from app import HttpError

# ----------------------------------------------------------------------------
# Server secret
# ----------------------------------------------------------------------------

_SECRET_FILE = os.path.join(os.path.dirname(__file__), "data", ".secret")


def _load_secret():
    """
    Read the signing secret from SCHEMEWISE_SECRET, else from a file we generate
    once and keep. Generating it means the demo works with no setup; reading the
    env var first means a real deployment can inject a managed secret.
    """
    env = os.environ.get("SCHEMEWISE_SECRET")
    if env:
        return env.encode("utf-8")

    os.makedirs(os.path.dirname(_SECRET_FILE), exist_ok=True)
    if os.path.exists(_SECRET_FILE):
        with open(_SECRET_FILE, "rb") as fh:
            data = fh.read().strip()
            if data:
                return data

    generated = secrets.token_bytes(48)
    with open(_SECRET_FILE, "wb") as fh:
        fh.write(generated)
    return generated


SECRET = _load_secret()


# ----------------------------------------------------------------------------
# Passwords — scrypt
# ----------------------------------------------------------------------------

# Cost parameters. n is the work factor; 2**14 takes a few milliseconds per
# attempt here, which is invisible to a real user and painful to a brute force.
_SCRYPT = dict(n=2 ** 14, r=8, p=1, dklen=32)


def hash_password(password):
    """Returns (hash_hex, salt_hex). Call this when a password is set."""
    if not isinstance(password, str) or len(password) < 6:
        raise HttpError(400, "Password must be at least 6 characters")
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, **_SCRYPT)
    return digest.hex(), salt.hex()


def verify_password(password, hash_hex, salt_hex):
    """Constant-time check. Never use == on secrets: timing leaks the answer."""
    if not password or not hash_hex or not salt_hex:
        return False
    try:
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(hash_hex)
    except ValueError:
        return False
    actual = hashlib.scrypt(password.encode("utf-8"), salt=salt, **_SCRYPT)
    return hmac.compare_digest(actual, expected)


# ----------------------------------------------------------------------------
# Tokens — a compact JWT (HS256)
# ----------------------------------------------------------------------------

def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _unb64(text):
    pad = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(text + pad)


def issue_token(claims, ttl_seconds=60 * 60 * 12):
    """
    Build header.payload.signature. `claims` carries who this is:
      {"sub": "<session token>", "role": "citizen"}  or
      {"sub": "admin", "role": "super_admin"}
    """
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    body = dict(claims)
    body["iat"] = now
    body["exp"] = now + ttl_seconds

    part1 = _b64(json.dumps(header, separators=(",", ":")).encode())
    part2 = _b64(json.dumps(body, separators=(",", ":"), default=str).encode())
    signing_input = ("%s.%s" % (part1, part2)).encode()
    signature = hmac.new(SECRET, signing_input, hashlib.sha256).digest()
    return "%s.%s.%s" % (part1, part2, _b64(signature))


def read_token(token):
    """
    Verify the signature and expiry, then return the claims.
    Returns None for anything malformed, tampered with, or expired.
    """
    if not token or token.count(".") != 2:
        return None
    part1, part2, sig = token.split(".")
    signing_input = ("%s.%s" % (part1, part2)).encode()
    expected = hmac.new(SECRET, signing_input, hashlib.sha256).digest()
    try:
        provided = _unb64(sig)
    except Exception:
        return None
    if not hmac.compare_digest(expected, provided):
        return None
    try:
        claims = json.loads(_unb64(part2))
    except Exception:
        return None
    if claims.get("exp", 0) < time.time():
        return None
    return claims


def new_session_token():
    """An opaque, unguessable id for an anonymous visitor."""
    return secrets.token_urlsafe(24)


# ----------------------------------------------------------------------------
# Rate limiting — token bucket per IP per bucket name
# ----------------------------------------------------------------------------

class RateLimiter:
    def __init__(self):
        self._buckets = {}
        self._lock = threading.Lock()

    def check(self, key, capacity, refill_per_second):
        """Raise 429 when this key has spent its allowance."""
        now = time.time()
        with self._lock:
            tokens, last = self._buckets.get(key, (float(capacity), now))
            tokens = min(capacity, tokens + (now - last) * refill_per_second)
            if tokens < 1:
                retry = max(1, int((1 - tokens) / refill_per_second))
                self._buckets[key] = (tokens, now)
                raise HttpError(429, "Too many requests. Try again in %ds." % retry)
            self._buckets[key] = (tokens - 1, now)

    def sweep(self, older_than=3600):
        cutoff = time.time() - older_than
        with self._lock:
            for key in [k for k, (_, last) in self._buckets.items() if last < cutoff]:
                del self._buckets[key]


limiter = RateLimiter()


# ----------------------------------------------------------------------------
# Input validation
# ----------------------------------------------------------------------------
# Every value that arrives from a browser is treated as hostile until it has
# been through here. This is what stops a crafted request from writing a
# 10 MB string into the database or setting an income of -1.

def need(data, field, kind, **rules):
    """
    Validate one field. Raises 400 with a readable message on failure.

        age = need(body, "age", int, minimum=15, maximum=100)
        name = need(body, "name", str, max_length=120)
    """
    if field not in data or data[field] is None:
        if "default" in rules:
            return rules["default"]
        raise HttpError(400, "Missing required field: %s" % field)

    value = data[field]

    if kind is int or kind is float:
        try:
            value = kind(value)
        except (TypeError, ValueError):
            raise HttpError(400, "Field %s must be a number" % field)
        if "minimum" in rules and value < rules["minimum"]:
            raise HttpError(400, "Field %s must be at least %s" % (field, rules["minimum"]))
        if "maximum" in rules and value > rules["maximum"]:
            raise HttpError(400, "Field %s must not exceed %s" % (field, rules["maximum"]))
        return value

    if kind is str:
        if not isinstance(value, str):
            raise HttpError(400, "Field %s must be text" % field)
        value = value.strip()
        if rules.get("required", True) and not value:
            raise HttpError(400, "Field %s cannot be empty" % field)
        max_length = rules.get("max_length", 2000)
        if len(value) > max_length:
            raise HttpError(400, "Field %s is longer than %d characters" % (field, max_length))
        if "choices" in rules and value not in rules["choices"]:
            raise HttpError(400, "Field %s must be one of: %s" % (field, ", ".join(rules["choices"])))
        return value

    if kind is bool:
        return bool(value)

    if kind is list:
        if not isinstance(value, list):
            raise HttpError(400, "Field %s must be a list" % field)
        if len(value) > rules.get("max_items", 200):
            raise HttpError(400, "Field %s has too many items" % field)
        return value

    if kind is dict:
        if not isinstance(value, dict):
            raise HttpError(400, "Field %s must be an object" % field)
        return value

    return value


def optional(data, field, kind, **rules):
    if field not in data or data[field] is None or data[field] == "":
        return rules.get("default")
    return need(data, field, kind, **rules)
