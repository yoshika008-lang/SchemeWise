"""
SchemeWise — the matching engine.

This is the single most important file in the backend, because this is the part
that used to run inside the browser. When the decision lives in the browser,
anybody who can press F12 can edit their own eligibility. Now the browser sends
answers and receives a verdict it cannot alter.

How a match is produced, for one applicant against one scheme:

  1. Run every rule in the scheme's rule set -> pass / warn / fail.
  2. Group the results into six areas and score each area 0..1
     (pass = 1, warn = 0.5, fail = 0).
  3. Weight the areas and normalise over the weight actually used, so a scheme
     with no income rule is not punished for having no income rule.
  4. Decide the verdict:
        any mandatory FAIL  -> ineligible
        any mandatory WARN  -> verify   ("we could not check this")
        otherwise           -> eligible
  5. Compute a benefit value, used ONLY to break ties in the ordering. It never
     changes whether somebody is eligible.

Point 4 is the design claim worth defending: an unanswered question produces
"needs verification", never a match. The product would rather say "prove it"
than tell someone they qualify when nobody checked.
"""

from engine.catalogue import rules_for, RULE_VERSION
from engine.rules import W

GROUP_WEIGHTS = {
    "purpose": 0.25,
    "applicant": 0.20,
    "income": 0.15,
    "location": 0.15,
    "cost": 0.15,
    "scheme": 0.10,
}

GROUP_LABEL = {
    "purpose": "Purpose match",
    "applicant": "Applicant eligibility",
    "income": "Income match",
    "location": "Location match",
    "cost": "Project cost match",
    "scheme": "Scheme conditions",
}

_STATUS_VALUE = {"pass": 1.0, "warn": 0.5, "fail": 0.0}


# ----------------------------------------------------------------------------
# One scheme
# ----------------------------------------------------------------------------

def evaluate_scheme(scheme, profile):
    rules = rules_for(scheme["id"])
    results = []

    for rule in rules:
        try:
            outcome = rule["fn"](profile, scheme)
        except Exception:
            # A rule that crashes must never become a silent pass.
            outcome = W("Could not be evaluated")
        results.append({
            "group": rule["group"],
            "label": rule["label"],
            "mandatory": rule["mandatory"],
            "status": outcome["status"],
            "note": outcome["note"],
        })

    blocking = [r for r in results if r["status"] == "fail" and r["mandatory"]]
    warnings = [r for r in results if r["status"] == "warn" and r["mandatory"]]
    # Advisory notes everyone declares at application time. They belong on the
    # card, but they must not demote a confirmed match.
    conditions = [r for r in results if r["status"] == "warn" and not r["mandatory"]]

    groups = {}
    for group in GROUP_WEIGHTS:
        in_group = [r for r in results if r["group"] == group]
        if not in_group:
            groups[group] = None
            continue
        groups[group] = sum(_STATUS_VALUE[r["status"]] for r in in_group) / len(in_group)

    weight_used = 0.0
    total = 0.0
    for group, weight in GROUP_WEIGHTS.items():
        if groups[group] is None:
            continue
        weight_used += weight
        total += weight * groups[group]
    score = round((total / weight_used) * 100) if weight_used else 0

    status = "ineligible" if blocking else ("verify" if warnings else "eligible")

    return {
        "scheme": scheme,
        "results": results,
        "groups": groups,
        "groupLabels": GROUP_LABEL,
        "score": score,
        "status": status,
        "blocking": blocking,
        "warnings": warnings,
        "conditions": conditions,
    }


# ----------------------------------------------------------------------------
# Money
# ----------------------------------------------------------------------------

def subsidy_for(scheme, profile):
    """
    What the applicant actually gets as a capital subsidy under this scheme.
    Scheme-specific because the rates are set scheme by scheme, not by a formula.
    """
    profile = profile or {}
    cost = profile.get("projectCost") or 0
    special = (profile.get("category") in ("sc", "st", "bc", "mbc", "minority")
               or profile.get("gender") == "female")
    sid = scheme["id"]

    if sid == "pmegp":
        rural = False  # urban rate assumed unless the applicant states otherwise
        pct = (35 if rural else 25) if special else (25 if rural else 15)
        return {"pct": pct, "amount": round(cost * pct / 100),
                "label": "%d%% margin money subsidy (urban rate)" % pct}

    if sid == "pmfme":
        return {"pct": 35, "amount": min(round(cost * 0.35), 1000000),
                "label": "35% credit-linked subsidy, capped at ₹10 lakh"}

    if sid == "uyegp":
        return {"pct": 25, "amount": min(round(cost * 0.25), 375000),
                "label": "25% capital subsidy, capped at ₹3.75 lakh"}

    if sid == "needs":
        return {"pct": 25, "amount": round(cost * 0.25),
                "label": "25% capital subsidy plus 3% interest subvention"}

    if sid == "vishwakarma":
        return {"pct": 0, "amount": 15000, "label": "₹15,000 toolkit incentive"}

    return {"pct": 0, "amount": 0, "label": "No capital subsidy under this scheme"}


def benefit_value(evaluation, profile):
    """
    How much this scheme is worth to this applicant. Used only to order equal
    scores and to mark the "largest benefit" card — never to decide eligibility.
    """
    scheme = evaluation["scheme"]
    profile = profile or {}
    cost = profile.get("projectCost") or 0

    subsidy_share = (subsidy_for(scheme, profile)["amount"] / cost) if cost else 0
    rate_min = scheme["rate"]["min"]
    cheap_credit = max(0, 13 - rate_min) / 13 if scheme["rate"]["max"] else 0
    reach = min(1, scheme["maxFinancing"] / cost) if (cost and scheme["maxFinancing"]) else 0

    return round((subsidy_share * 60 + cheap_credit * 25 + reach * 15) * 10) / 10


# ----------------------------------------------------------------------------
# All schemes
# ----------------------------------------------------------------------------

def run_engine(schemes, profile):
    """Evaluate every active scheme and sort into the three buckets."""
    if not profile:
        return {"eligible": [], "verify": [], "ineligible": [], "all": [],
                "ruleVersion": RULE_VERSION}

    evaluated = []
    for scheme in schemes:
        if scheme.get("active") is False:
            continue
        ev = evaluate_scheme(scheme, profile)
        ev["value"] = benefit_value(ev, profile)
        evaluated.append(ev)

    def order(ev):
        return (-ev["score"], -ev["value"])

    return {
        "eligible": sorted([e for e in evaluated if e["status"] == "eligible"], key=order),
        "verify": sorted([e for e in evaluated if e["status"] == "verify"], key=order),
        "ineligible": sorted([e for e in evaluated if e["status"] == "ineligible"], key=order),
        "all": evaluated,
        "ruleVersion": RULE_VERSION,
    }


# ----------------------------------------------------------------------------
# Profile hygiene
# ----------------------------------------------------------------------------

NUMERIC_FIELDS = {
    "age": (10, 110),
    "income": (0, 100000000),
    "projectCost": (0, 1000000000),
    "amountNeeded": (0, 1000000000),
    "experienceYears": (0, 70),
}

TEXT_FIELDS = [
    "state", "district", "city", "employment", "education", "requirement",
    "sector", "stage", "category", "gender", "disability", "residency3",
    "firstGen", "loanStatus",
]


def clean_profile(raw):
    """
    Accept only the fields the engine knows about, coerce the numbers, and cap
    the strings. Anything else a browser sends is dropped on the floor before
    it reaches a rule or the database.
    """
    if not isinstance(raw, dict):
        return {}
    out = {}

    for field, (low, high) in NUMERIC_FIELDS.items():
        if raw.get(field) is None or raw.get(field) == "":
            continue
        try:
            value = float(raw[field])
        except (TypeError, ValueError):
            continue
        out[field] = int(max(low, min(high, value)))

    for field in TEXT_FIELDS:
        value = raw.get(field)
        if isinstance(value, str) and value.strip():
            out[field] = value.strip()[:120]

    return out
