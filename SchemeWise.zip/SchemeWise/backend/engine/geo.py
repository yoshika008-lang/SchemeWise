"""
SchemeWise — routing an applicant to the office that can actually help them.

"Where do I apply?" is a real question with a wrong answer people give all the
time: the nearest bank. The nearest bank often does not handle the scheme.

So the ranking is not distance-first. An office scores on three things:

    does it handle this exact scheme   50%
    is it the right type of office     25%
    how far away is it                 25%

which is why a District Industries Centre three kilometres further away can
outrank the branch on the corner. Distance alone would send people to the
wrong counter, and being sent to the wrong counter is the failure this product
exists to prevent.
"""

import math


def haversine(a, b):
    """Great-circle distance in kilometres between two [lat, lng] points."""
    radius = 6371.0
    lat1, lng1 = math.radians(a[0]), math.radians(a[1])
    lat2, lng2 = math.radians(b[0]), math.radians(b[1])
    d_lat = lat2 - lat1
    d_lng = lng2 - lng1
    h = math.sin(d_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(d_lng / 2) ** 2
    return 2 * radius * math.asin(math.sqrt(h))


def route_partners(partners, origin=None, scheme_id=None, kind="all"):
    """Rank offices for this applicant. Returns the scored list, best first."""
    scored = []

    for p in partners:
        if kind and kind != "all" and p["kind"] != kind:
            continue

        distance = haversine(origin, [p["lat"], p["lng"]]) if origin else None
        handles = (scheme_id in p["handles"]) if scheme_id else True

        # Anything past 40 km scores zero on proximity; with no location at all
        # we assume the middle rather than pretending to know.
        proximity = 0.5 if distance is None else max(0.0, 1 - min(distance, 40) / 40)
        type_fit = (1.0 if handles else 0.2) if scheme_id else 0.6

        score = round((0.5 * (1 if handles else 0) + 0.25 * type_fit + 0.25 * proximity) * 100)

        scored.append({
            "p": p,
            "dist": round(distance, 2) if distance is not None else None,
            "handles": handles,
            "score": score,
        })

    scored.sort(key=lambda x: (-x["score"], 99 if x["dist"] is None else x["dist"]))
    return scored


KIND_LABEL = {
    "dic": "District Industries Centre",
    "kvic": "Khadi & Village Industries",
    "bank": "Bank",
    "rrb": "Regional rural bank",
    "state_agency": "State agency",
    "csc": "Common Service Centre",
    "mfi": "Microfinance institution",
    "training": "Training centre",
    "incubator": "Startup incubator",
}
