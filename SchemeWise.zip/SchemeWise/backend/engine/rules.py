"""
SchemeWise — rule primitives.

A rule is a small function that looks at one applicant and one scheme and
returns one of three verdicts:

    PASS  the condition is met, and here is the sentence that proves it
    WARN  we could not check this from what the applicant told us
    FAIL  the condition is definitely not met

WARN is the important one, and it is the reason this engine is not a filter.
An unanswered question is never silently treated as a pass. A scheme carrying
a WARN on a mandatory rule is moved out of "recommended" and into "needs
verification", so the product never tells somebody they qualify when nobody
actually checked.

Every rule also carries a `group` (purpose / applicant / income / location /
cost / scheme) so the score can be broken down by area rather than handed
over as one unexplained number.
"""

# ----------------------------------------------------------------------------
# Verdicts
# ----------------------------------------------------------------------------

def P(note):
    return {"status": "pass", "note": note}


def W(note):
    return {"status": "warn", "note": note}


def F(note):
    return {"status": "fail", "note": note}


def R(group, label, fn, mandatory=True):
    """Build one rule. `fn(profile, scheme)` returns P/W/F."""
    return {"group": group, "label": label, "fn": fn, "mandatory": mandatory}


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def known(v):
    """
    True when the applicant actually answered. "unspecified" and "unsure" are
    real answers in the form and both mean "I don't know" — they are not data.
    """
    return v is not None and v != "" and v != "unspecified" and v != "unsure"


def inr(n):
    """1234567 -> '₹12,34,567' (Indian digit grouping)."""
    if n is None:
        return "—"
    x = int(round(n))
    s = str(abs(x))
    if len(s) > 3:
        last3 = s[-3:]
        rest = s[:-3]
        parts = []
        while len(rest) > 2:
            parts.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            parts.insert(0, rest)
        s = ",".join(parts) + "," + last3
    return ("-" if x < 0 else "") + "₹" + s


def compact(n):
    """1000000 -> '₹10 lakh'. Matches how the amounts read on the page."""
    if n is None:
        return "—"
    if n >= 10000000:
        v = n / 10000000
        return "₹%s crore" % (int(v) if n % 10000000 == 0 else round(v, 2))
    if n >= 100000:
        v = n / 100000
        return "₹%s lakh" % (int(v) if n % 100000 == 0 else round(v, 1))
    return inr(n)


EDU_ORDER = {"none": 0, "8": 1, "10": 2, "12": 3, "iti": 4, "degree": 5}
MFG_SECTORS = ["food_processing", "manufacturing", "textiles", "handicrafts"]
SPECIAL_CATEGORIES = ["sc", "st", "bc", "mbc", "minority"]


def is_special(p):
    """Categories that attract a relaxation or a higher subsidy rate."""
    return p.get("category") in SPECIAL_CATEGORIES or p.get("gender") == "female"


def edu_level(p):
    return EDU_ORDER.get(p.get("education"), -1)


def need_amount(p):
    """Assistance required, falling back to project cost."""
    return p.get("amountNeeded") or p.get("projectCost")


# ----------------------------------------------------------------------------
# Parameterised rules
# ----------------------------------------------------------------------------

def age_rule(minimum, maximum=None, relax_max=None, relax_note=None):
    def check(p, s):
        if not known(p.get("age")):
            return W("Age not provided")
        age = p["age"]
        ceiling = relax_max if (is_special(p) and relax_max) else maximum
        if age < minimum:
            return F("Minimum age is %d" % minimum)
        if ceiling and age > ceiling:
            return F("Upper age limit is %d%s" % (ceiling, " — " + relax_note if relax_note else ""))
        if maximum:
            return P("%d is within %d–%d" % (age, minimum, ceiling))
        return P("%d meets the minimum of %d" % (age, minimum))

    return R("applicant", "Age requirement", check)


def income_rule(limit, label=None):
    def check(p, s):
        if not limit:
            return P("This scheme has no family income ceiling")
        if not known(p.get("income")):
            return W("Income not provided")
        if p["income"] <= limit:
            return P("%s is within the %s ceiling" % (compact(p["income"]), compact(limit)))
        return F("Family income must not exceed %s (%s)" % (compact(limit), label or "annual"))

    return R("income", "Income requirement", check)


def state_rule(states):
    def check(p, s):
        if "ALL" in states:
            return P("Available across India")
        if not known(p.get("state")):
            return W("State not provided")
        if p["state"] in states:
            return P("%s is covered by this scheme" % p["state"])
        return F("Restricted to %s" % ", ".join(states))

    return R("location", "Location requirement", check)


def purpose_rule(purposes):
    def check(p, s):
        if not known(p.get("requirement")):
            return W("Requirement not selected")
        if p["requirement"] in purposes:
            return P("Your stated requirement is a funded purpose")
        return F("This scheme does not fund the purpose you selected")

    return R("purpose", "Purpose requirement", check)


def category_rule(allowed, label_text, allow_women=False):
    def check(p, s):
        if allow_women and p.get("gender") == "female":
            return P("Women applicants are covered")
        if not known(p.get("category")):
            return W("Restricted to %s — category not confirmed" % label_text)
        if p["category"] in allowed:
            return P("%s applicants are covered" % label_text)
        return F("This scheme is reserved by statute for %s" % label_text)

    return R("applicant", "Applicant category", check)


def cost_rule(minimum, maximum, note=None):
    def check(p, s):
        v = p.get("projectCost")
        if not known(v):
            return W("Project cost not provided")
        if minimum and v < minimum:
            return F("Project cost must be at least %s" % compact(minimum))
        if maximum and v > maximum:
            return F("Project cost above the %s ceiling%s" % (compact(maximum), " — " + note if note else ""))
        return P("%s sits within %s–%s" % (compact(v), compact(minimum or 0), compact(maximum)))

    return R("cost", "Project cost / loan limit", check)


def edu_rule(level, label_text, soft_below=None):
    def check(p, s):
        if not known(p.get("education")):
            return W("Education not provided")
        if edu_level(p) >= EDU_ORDER[level]:
            return P("%s requirement met" % label_text)
        if soft_below and p.get("projectCost") and p["projectCost"] <= soft_below:
            return P("Below the cost threshold where this requirement applies")
        return F("%s is required" % label_text)

    return R("applicant", "Education requirement", check)


def sector_rule(sectors, label_text):
    def check(p, s):
        if not known(p.get("sector")):
            return W("Sector not provided")
        if p["sector"] in sectors:
            return P("%s is an eligible activity" % label_text)
        return F("Limited to %s" % label_text)

    return R("scheme", "Sector requirement", check)


def new_unit_rule():
    def check(p, s):
        if not known(p.get("stage")):
            return W("Business stage not provided")
        if p["stage"] == "new":
            return P("Funded for new (greenfield) units")
        return F("Only new units are financed under this scheme")

    return R("scheme", "New enterprise only", check)


def no_default_rule():
    def check(p, s):
        if not known(p.get("loanStatus")):
            return W("Loan status not provided")
        if p["loanStatus"] == "default":
            return F("Applicants in default with a bank are not eligible")
        return P("No declared default with a lender")

    return R("scheme", "Credit standing", check)
