"""
SchemeWise — the rule catalogue.

This is the part of the system that is deliberately NOT in the database.

A scheme has two halves:

  * the RECORD  — name, ceilings, interest range, documents, verification date.
    That changes when a government order revises a figure, so an administrator
    edits it through the admin screen and it lives in the `schemes` table.

  * the LOGIC   — "under 45 unless you are SC/ST/women, in which case 45",
    "Class VIII if the project is above ₹10 lakh". That is a legal test. It
    belongs in version control where every change is a reviewable commit, not
    in a text box someone can retype at 2 a.m.

So: records are data, rules are code, and they are joined at match time by
scheme id. A scheme record with no rule set here is scored on its record alone
and flagged, rather than silently treated as a match.

RULE_VERSION is stamped onto every match response, so a verdict this product
gave last month can always be reproduced against the rules that produced it.
"""

from engine.rules import (
    P, W, F, R, known, compact,
    EDU_ORDER, MFG_SECTORS,
    age_rule, income_rule, state_rule, purpose_rule, category_rule,
    cost_rule, edu_rule, sector_rule, new_unit_rule, no_default_rule,
    edu_level, need_amount,
)

RULE_VERSION = "2026.09.1"


# ----------------------------------------------------------------------------
# Custom rules — one function per scheme-specific condition
# ----------------------------------------------------------------------------

def _pmegp_cost(p, s):
    if not known(p.get("projectCost")):
        return W("Project cost not provided")
    is_mfg = p.get("sector") in MFG_SECTORS
    cap = 5000000 if is_mfg else 2000000
    label = "manufacturing" if is_mfg else "service or business"
    if p["projectCost"] > cap:
        return F("Ceiling for %s activity is %s; the balance can be financed without subsidy"
                 % (label, compact(cap)))
    return P("%s is within the %s %s ceiling" % (compact(p["projectCost"]), compact(cap), label))


def _pmegp_education(p, s):
    is_mfg = p.get("sector") in MFG_SECTORS
    threshold = 1000000 if is_mfg else 500000
    if not known(p.get("projectCost")):
        return W("Project cost not provided")
    if p["projectCost"] <= threshold:
        return P("No minimum education below %s for this activity" % compact(threshold))
    if not known(p.get("education")):
        return W("Education not provided")
    if edu_level(p) >= EDU_ORDER["8"]:
        return P("Class VIII requirement met")
    return F("Class VIII pass is required above %s" % compact(threshold))


def _mudra_limit(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Assistance amount not provided")
    if need > 2000000:
        return F("MUDRA is capped at ₹20 lakh — a larger requirement needs a different facility")
    tier = ("Shishu" if need <= 50000 else
            "Kishore" if need <= 500000 else
            "Tarun" if need <= 1000000 else "Tarun Plus")
    return P("%s falls in the %s tier" % (compact(need), tier))


def _mudra_track_record(p, s):
    need = need_amount(p) or 0
    if need > 1000000:
        return W("Tarun Plus is for borrowers who have repaid an earlier Tarun loan")
    if need > 500000 and p.get("stage") == "new":
        return W("Tarun-tier lending usually expects operating history; a new unit may be routed to a smaller tier")
    return P("Tier is appropriate for your stage")


def _mudra_non_farm(p, s):
    if p.get("sector") == "agri_allied":
        return W("Allied activity such as dairy or poultry is covered; crop cultivation is not")
    return P("Non-farm enterprise activity")


def _standup_band(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Assistance amount not provided")
    if need < 1000000:
        return F("The scheme starts at ₹10 lakh; smaller requirements are served by MUDRA")
    if need > 10000000:
        return F("The scheme is capped at ₹1 crore")
    return P("%s is inside the ₹10 lakh–₹1 crore band" % compact(need))


def _pmfme_education(p, s):
    if not known(p.get("education")):
        return W("Education not provided — states commonly apply a Class VIII minimum for individual applicants")
    if edu_level(p) >= EDU_ORDER["8"]:
        return P("Meets the Class VIII minimum applied by most states")
    return W("Most State Nodal Agencies apply a Class VIII minimum for individual applicants — confirm locally")


def _vishwakarma_trade(p, s):
    if p.get("sector") in ("handicrafts", "textiles"):
        return W("Your sector may fall under one of the 18 notified trades — the specific trade must be confirmed at registration")
    return W("Eligibility depends on practising one of the 18 notified family-based trades")


def _vishwakarma_credit(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Assistance amount not provided")
    if need > 300000:
        return F("Enterprise credit is limited to ₹1 lakh, then ₹2 lakh on repayment")
    return P("%s is within the ₹3 lakh two-tranche limit" % compact(need))


def _uyegp_age(p, s):
    if not known(p.get("age")):
        return W("Age not provided")
    if p["age"] < 18:
        return F("Minimum age is 18")
    if p["age"] > 45:
        return W("Upper age limit varies by category under current guidelines — confirm with the District Industries Centre")
    return P("%d is within the usual 18–45 range" % p["age"])


def _needs_first_gen(p, s):
    if not known(p.get("firstGen")):
        return W("First-generation status not confirmed")
    if p["firstGen"] == "yes":
        return P("First-generation entrepreneur")
    return F("Restricted to first-generation entrepreneurs")


def _needs_residency(p, s):
    if not known(p.get("residency3")):
        return W("Three-year residence not confirmed")
    if p["residency3"] == "yes":
        return P("Three-year Tamil Nadu residence met")
    return F("Three years of residence in Tamil Nadu is required")


def _nsfdc_edu_limit(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Amount required not provided")
    if need > 2000000:
        return F("Above the limit applied for study abroad")
    return P("%s is within the published limits" % compact(need))


def _vidyalaxmi_interest(p, s):
    if not known(p.get("income")):
        return W("Income not provided — the loan has no income ceiling, the interest benefit does")
    if p["income"] <= 450000:
        return P("Eligible for full interest subvention during moratorium under PM-USP CSIS")
    if p["income"] <= 800000:
        return P("Eligible for 3% interest subvention on loans up to ₹10 lakh")
    return P("Loan available without income ceiling; interest subvention does not apply above ₹8 lakh")


def _vidyalaxmi_amount(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Amount required not provided")
    if need > 1000000:
        return P("%s can be financed; interest subvention applies only to the first ₹10 lakh" % compact(need))
    return P("%s is within the subvention-eligible amount" % compact(need))


def _svanidhi_cycle(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Amount required not provided")
    if need > 50000:
        return F("The largest cycle is ₹50,000 — a bigger requirement needs MUDRA instead")
    return P("%s fits the cycle structure" % compact(need))


def _cgtmse_enterprise(p, s):
    if p.get("sector") == "agri_allied":
        return W("Cover is for micro and small enterprises in manufacturing and services; agricultural activity is excluded")
    return P("Micro and small enterprise activity is covered")


def _sisfs_size(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Amount required not provided")
    if need > 7000000:
        return F("Grant and debt together are capped near ₹70 lakh")
    return P("%s is within the grant and debt components" % compact(need))


def _nulm_income(p, s):
    if not known(p.get("income")):
        return W("Income not provided")
    if p["income"] <= 300000:
        return P("%s is in the range cities normally treat as eligible — the ULB list decides" % compact(p["income"]))
    return W("Cities apply their own urban poor identification; higher incomes are usually excluded")


def _nmdfc_income(p, s):
    if not known(p.get("income")):
        return W("Income not provided")
    if p["income"] <= 600000:
        return P("%s is within the household income criterion the corporation applies" % compact(p["income"]))
    return F("Above the household income criterion applied by the corporation")


def _ndfdc_disability(p, s):
    if not known(p.get("disability")):
        return W("Reserved for persons with a benchmark disability — not confirmed")
    if p["disability"] == "yes":
        return P("Benchmark disability certificate covers you for this corporation's schemes")
    return F("Restricted to persons with a benchmark disability")


def _nstfdc_income(p, s):
    if not known(p.get("income")):
        return W("Income not provided")
    if p["income"] <= 300000:
        return P("%s is within the criterion state agencies commonly apply" % compact(p["income"]))
    return W("The corporation's income criterion is applied by the state agency and is revised periodically — confirm locally")


def _pmusp_amount(p, s):
    need = need_amount(p)
    if not known(need):
        return W("Amount required not provided")
    if need > 1000000:
        return P("Interest subsidy applies to the first ₹10 lakh of the loan")
    return P("%s is fully within the subsidised amount" % compact(need))


def _always(note, verdict=P):
    """A rule whose answer never depends on the applicant."""
    return lambda p, s: verdict(note)


# ----------------------------------------------------------------------------
# The catalogue — scheme id -> ordered list of rules
# ----------------------------------------------------------------------------

RULES = {

    "pmegp": [
        purpose_rule(["start_business", "equipment", "self_employment"]),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        R("cost", "Project cost limit", _pmegp_cost),
        R("applicant", "Education requirement", _pmegp_education),
        new_unit_rule(),
        R("scheme", "One benefit per family",
          _always("Only one member per family, and no earlier PMRY / REGP / PMEGP subsidy — declared at application", W),
          mandatory=False),
    ],

    "mudra": [
        purpose_rule(["start_business", "expand_business", "equipment", "working_capital", "self_employment"]),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        R("cost", "Loan limit", _mudra_limit),
        R("scheme", "Track record for higher tiers", _mudra_track_record, mandatory=False),
        R("scheme", "Non-farm activity", _mudra_non_farm, mandatory=False),
        no_default_rule(),
    ],

    "standup": [
        purpose_rule(["start_business", "equipment", "working_capital"]),
        state_rule(["ALL"]),
        category_rule(["sc", "st"], "SC and ST", allow_women=True),
        age_rule(18),
        income_rule(None),
        R("cost", "Loan band", _standup_band),
        new_unit_rule(),
        no_default_rule(),
    ],

    "pmfme": [
        purpose_rule(["start_business", "expand_business", "equipment"]),
        sector_rule(["food_processing"], "food processing and value addition"),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        cost_rule(100000, 5000000, "subsidy is still capped at ₹10 lakh"),
        R("scheme", "Existing or new unit", _always("Both new and existing micro units are eligible")),
        R("applicant", "Education requirement", _pmfme_education, mandatory=False),
    ],

    "vishwakarma": [
        purpose_rule(["self_employment", "equipment", "working_capital", "skill_development"]),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        R("scheme", "Listed traditional trade", _vishwakarma_trade),
        R("cost", "Credit limit", _vishwakarma_credit),
        R("scheme", "No recent similar credit",
          _always("Applicants who took PMEGP, MUDRA or PM SVANidhi credit in recent years are restricted — confirm at registration", W),
          mandatory=False),
    ],

    "uyegp": [
        purpose_rule(["start_business", "equipment", "self_employment"]),
        state_rule(["Tamil Nadu"]),
        income_rule(500000, "family"),
        edu_rule("8", "Class VIII"),
        cost_rule(50000, 1500000, "sector-wise sub-limits apply"),
        R("applicant", "Age requirement", _uyegp_age),
        new_unit_rule(),
        R("scheme", "No other government assistance",
          _always("Applicants who have taken subsidy under another state or central scheme are excluded — declared at application", W),
          mandatory=False),
    ],

    "needs": [
        purpose_rule(["start_business", "equipment"]),
        state_rule(["Tamil Nadu"]),
        age_rule(21, 35, 45, "relaxed to 45 for special categories"),
        edu_rule("iti", "Degree, diploma, ITI or vocational qualification"),
        cost_rule(1000000, 50000000),
        income_rule(None),
        new_unit_rule(),
        R("applicant", "First-generation entrepreneur", _needs_first_gen),
        R("location", "Residence duration", _needs_residency),
    ],

    "nsfdc_term": [
        purpose_rule(["start_business", "expand_business", "equipment", "self_employment", "working_capital"]),
        category_rule(["sc"], "Scheduled Caste"),
        income_rule(300000, "family"),
        state_rule(["ALL"]),
        age_rule(18, 55),
        cost_rule(125000, 4500000),
        no_default_rule(),
    ],

    "nsfdc_edu": [
        purpose_rule(["education"]),
        category_rule(["sc"], "Scheduled Caste"),
        income_rule(300000, "family"),
        state_rule(["ALL"]),
        R("cost", "Loan limit", _nsfdc_edu_limit),
        R("scheme", "Course recognition",
          _always("The course must be a recognised professional or technical programme — confirmed by the agency", W),
          mandatory=False),
    ],

    "vidyalaxmi": [
        purpose_rule(["education"]),
        state_rule(["ALL"]),
        R("scheme", "Listed institution",
          _always("Admission must be through merit to an institution on the notified QHEI list — check the portal for your institution", W)),
        R("income", "Interest benefit", _vidyalaxmi_interest),
        R("cost", "Loan amount", _vidyalaxmi_amount),
    ],

    "pmkvy": [
        purpose_rule(["skill_development", "self_employment"]),
        state_rule(["ALL"]),
        age_rule(15, 45),
        income_rule(None),
        R("cost", "Cost to applicant", _always("No project cost — training is funded")),
        R("scheme", "Course availability",
          _always("Course availability depends on centres empanelled in your district", W),
          mandatory=False),
    ],

    "svanidhi": [
        purpose_rule(["working_capital", "self_employment"]),
        sector_rule(["street_vending"], "street vending"),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        R("cost", "Loan cycle limit", _svanidhi_cycle),
        R("scheme", "Vendor identification",
          _always("A Certificate of Vending or ULB letter of recommendation must be in hand before the lender can process this", W)),
    ],

    "cgtmse": [
        purpose_rule(["start_business", "expand_business", "equipment", "working_capital", "self_employment"]),
        state_rule(["ALL"]),
        income_rule(None),
        R("scheme", "Applies through a lender",
          _always("Cover is arranged by the bank on an underlying loan — pair it with one of the credit schemes here", W)),
        R("applicant", "Enterprise type", _cgtmse_enterprise),
        R("cost", "Facility size", _always("Applies across the usual micro and small enterprise loan sizes")),
    ],

    "sisfs": [
        purpose_rule(["start_business", "expand_business", "equipment"]),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        R("scheme", "Recognition and structure",
          _always("Requires DPIIT recognition and incorporation as a company or LLP within the last two years — a proprietorship cannot apply", W)),
        R("cost", "Support size", _sisfs_size),
        R("applicant", "Innovation test",
          _always("The incubator committee judges whether the product is technology-led and scalable", W)),
    ],

    "nulm_sep": [
        purpose_rule(["start_business", "self_employment", "equipment", "working_capital"]),
        state_rule(["ALL"]),
        age_rule(18),
        R("income", "Urban poor identification", _nulm_income),
        cost_rule(25000, 1000000),
        R("scheme", "City mission coverage",
          _always("Assistance depends on your urban local body operating the programme this year", W)),
    ],

    "aif": [
        purpose_rule(["start_business", "expand_business", "equipment"]),
        sector_rule(["agri_allied", "food_processing"], "post-harvest, agri-allied and food processing infrastructure"),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        cost_rule(500000, 100000000),
        R("scheme", "Eligible asset",
          _always("The asset must fall in the notified post-harvest or community farming list — confirmed at project appraisal", W),
          mandatory=False),
    ],

    "ddugky": [
        purpose_rule(["skill_development", "self_employment"]),
        state_rule(["ALL"]),
        age_rule(15, 35, 45, "relaxed for women and vulnerable groups"),
        income_rule(None),
        R("location", "Rural residence",
          _always("The programme serves rural households; urban applicants are directed to Skill India instead", W)),
        R("cost", "Cost to applicant", _always("No project cost — training is funded")),
    ],

    "nbcfdc": [
        purpose_rule(["start_business", "expand_business", "equipment", "self_employment", "working_capital"]),
        category_rule(["bc", "mbc"], "Backward Class"),
        income_rule(500000, "family"),
        state_rule(["ALL"]),
        age_rule(18, 55),
        cost_rule(50000, 2500000, "sub-scheme ceilings vary"),
        no_default_rule(),
    ],

    "nmdfc": [
        purpose_rule(["start_business", "expand_business", "equipment", "self_employment", "working_capital", "education"]),
        category_rule(["minority"], "notified minority communities"),
        R("income", "Income criterion", _nmdfc_income),
        state_rule(["ALL"]),
        age_rule(18, 55),
        cost_rule(25000, 2000000),
        R("scheme", "Variant limits",
          _always("Term loan, micro-finance and education variants carry different ceilings — confirm with the state agency", W),
          mandatory=False),
    ],

    "ndfdc": [
        purpose_rule(["start_business", "expand_business", "equipment", "self_employment", "working_capital", "education"]),
        R("applicant", "Disability requirement", _ndfdc_disability),
        state_rule(["ALL"]),
        age_rule(18),
        income_rule(None),
        cost_rule(25000, 5000000),
        no_default_rule(),
    ],

    "nstfdc": [
        purpose_rule(["start_business", "expand_business", "equipment", "self_employment", "working_capital"]),
        category_rule(["st"], "Scheduled Tribe"),
        R("income", "Income criterion", _nstfdc_income),
        state_rule(["ALL"]),
        age_rule(18, 55),
        cost_rule(50000, 5000000),
        no_default_rule(),
    ],

    "tahdco_se": [
        purpose_rule(["start_business", "equipment", "self_employment", "working_capital"]),
        category_rule(["sc", "st"], "Scheduled Caste and Scheduled Tribe"),
        state_rule(["Tamil Nadu"]),
        income_rule(300000, "family"),
        age_rule(18, 60),
        cost_rule(50000, 1000000),
        R("scheme", "Current scheme pattern",
          _always("Limits and subsidy share are revised by government order — confirm the current pattern at the district office", W),
          mandatory=False),
    ],

    "pms_sc": [
        purpose_rule(["education"]),
        category_rule(["sc"], "Scheduled Caste"),
        income_rule(250000, "family"),
        state_rule(["ALL"]),
        R("cost", "Nature of support", _always("Fee reimbursement and maintenance rather than a loan amount")),
        R("scheme", "Course level",
          _always("The course must be post-matriculation in a recognised institution and within the application window", W),
          mandatory=False),
    ],

    "pmusp_csis": [
        purpose_rule(["education"]),
        state_rule(["ALL"]),
        income_rule(450000, "family"),
        R("cost", "Loan amount covered", _pmusp_amount),
        R("scheme", "Course and institution",
          _always("The course must be technical or professional at a NAAC-accredited institution or NBA-accredited programme", W)),
    ],
}


def rules_for(scheme_id):
    """
    The rule set for a scheme. A record with no rules yet returns a single
    honest WARN rather than a free pass — an unwritten rule is not a match.
    """
    found = RULES.get(scheme_id)
    if found:
        return found
    return [R("scheme", "Eligibility rules pending",
              _always("Eligibility logic for this record has not been published yet — it cannot be confirmed as a match", W))]
