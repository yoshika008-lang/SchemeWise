"""SchemeWise eligibility engine."""
