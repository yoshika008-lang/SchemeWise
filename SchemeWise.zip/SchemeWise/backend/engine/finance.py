"""
SchemeWise — loan mathematics.

Everything on the calculator screen is computed here, on the server. The
browser sends five numbers and renders whatever comes back; it does no
arithmetic of its own. That matters because these figures are what somebody
plans their family finances around, so there is exactly one implementation of
them, it is testable, and it can be corrected once for every user at once.

The moratorium handling is the part people get wrong. During a moratorium you
do not pay, but interest still accrues. We add that accrued interest to the
principal before computing the instalment, and report it separately so nobody
is surprised by it later.
"""


def compute_finance(project_cost, rate, years, moratorium_months=0,
                    subsidy_amount=0, contribution_pct=10):
    """
    Returns the full financing picture:

        contribution     what the applicant puts in
        loan             what the bank actually lends
        emi              equated monthly instalment
        mor_interest     interest that accrues during the moratorium
        total_interest   interest over the life of the loan
        total_repayment  everything paid back
        schedule         outstanding balance at the end of each year
    """
    project_cost = max(0.0, float(project_cost or 0))
    rate = max(0.0, float(rate or 0))
    years = max(1, int(years or 1))
    moratorium_months = max(0, int(moratorium_months or 0))
    subsidy_amount = max(0.0, float(subsidy_amount or 0))
    contribution_pct = min(100.0, max(0.0, float(contribution_pct or 0)))

    contribution = round(project_cost * contribution_pct / 100)
    loan = max(project_cost - contribution - subsidy_amount, 0)

    monthly_rate = rate / 1200.0
    months = max(round(years * 12), 1)

    # Interest accrued while no instalment is being paid, capitalised.
    mor_interest = loan * monthly_rate * moratorium_months
    base = loan + mor_interest

    if monthly_rate == 0:
        emi = base / months
    else:
        growth = (1 + monthly_rate) ** months
        emi = (base * monthly_rate * growth) / (growth - 1)

    total_repayment = emi * months
    total_interest = total_repayment - loan

    schedule = []
    balance = base
    for month in range(1, months + 1):
        interest = balance * monthly_rate
        balance = max(balance + interest - emi, 0)
        if month % 12 == 0 or month == months:
            schedule.append({"year": -(-month // 12), "balance": round(balance)})

    return {
        "contribution": contribution,
        "loan": round(loan),
        "emi": round(emi, 2),
        "morInterest": round(mor_interest, 2),
        "totalInterest": round(total_interest, 2),
        "totalRepayment": round(total_repayment, 2),
        "schedule": schedule,
        "months": months,
    }


def quote(scheme, profile, cost, rate, years, moratorium_months, contribution_pct, subsidy):
    """
    A complete calculator answer for one scheme: cap the cost at the scheme's
    ceiling, work out the eligible financing, then run the loan maths.
    """
    project_max = scheme.get("projectMax") or 0
    capped_cost = min(cost, project_max) if project_max else cost
    was_capped = capped_cost < cost

    financing_pct = scheme.get("financingPct") or 0
    max_financing = scheme.get("maxFinancing") or 0
    eligible_financing = min(round(capped_cost * financing_pct / 100), max_financing) if max_financing else 0

    finance = compute_finance(
        project_cost=capped_cost,
        rate=rate,
        years=years,
        moratorium_months=moratorium_months,
        subsidy_amount=subsidy["amount"],
        contribution_pct=contribution_pct,
    )

    return {
        "schemeId": scheme["id"],
        "schemeName": scheme["name"],
        "projectCost": capped_cost,
        "cappedAtCeiling": was_capped,
        "projectMax": project_max,
        "eligibleFinancing": eligible_financing,
        "subsidy": subsidy,
        **finance,
    }
