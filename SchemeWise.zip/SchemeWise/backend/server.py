"""
SchemeWise — server entry point.

    python backend/server.py

That is the whole setup. No pip install, no database server, no build step.
On first run it creates the SQLite database, loads 24 scheme records and the
office directory, creates the default staff accounts, and serves both the API
and the frontend on http://localhost:8000.

Options:
    --port 8000          change the port
    --host 0.0.0.0       expose to your phone on the same wifi (for the demo)
    --no-browser         don't open a browser window
    --reset              delete the database and start clean
"""

import argparse
import mimetypes
import os
import sys
import threading
import time
import webbrowser

# Make `import db`, `import engine.x`, `import routes.x` work no matter where
# the command was run from.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app import App, Response, run          # noqa: E402
import db                                    # noqa: E402
import routes                                # noqa: E402
from routes._helpers import attach_identity, rate_limit   # noqa: E402

FRONTEND_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "frontend"))


# ----------------------------------------------------------------------------
# .env
# ----------------------------------------------------------------------------

def load_env():
    """
    Read backend/.env into the process environment. This is where GEMINI_API_KEY
    goes. The file is in .gitignore, and nothing in it is ever sent to a browser.
    """
    path = os.path.join(BASE_DIR, ".env")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


# ----------------------------------------------------------------------------
# Static files — the frontend
# ----------------------------------------------------------------------------

def make_static_handler():
    """
    Serve frontend/ so the whole product runs from one origin. This matters for
    a practical reason: a page opened as file:// cannot call an API, so the
    server hosting the page is what makes the demo work on any machine.
    """
    def serve(url_path):
        rel = url_path.lstrip("/")
        if rel in ("", "index.html"):
            rel = "index.html"
        elif rel.startswith("api"):
            return None

        target = os.path.abspath(os.path.join(FRONTEND_DIR, rel))
        # Refuse anything that tries to climb out of frontend/ with ../
        if not target.startswith(FRONTEND_DIR) or not os.path.isfile(target):
            if rel != "index.html":
                return None
            return Response({"error": "frontend/index.html is missing"}, status=404)

        content_type, _ = mimetypes.guess_type(target)
        with open(target, "rb") as fh:
            body = fh.read()
        return Response(
            body,
            status=200,
            content_type=(content_type or "application/octet-stream") +
                         ("; charset=utf-8" if (content_type or "").startswith("text") else ""),
            headers={"Cache-Control": "no-store"},
        )

    return serve


# ----------------------------------------------------------------------------
# Build the app
# ----------------------------------------------------------------------------

def create_app():
    app = App()
    app.use(rate_limit)          # 1. is this caller over budget?
    app.use(attach_identity)     # 2. who are they, provably?
    routes.register_all(app)     # 3. the endpoints
    return app


def banner(host, port, route_count):
    display = "localhost" if host in ("0.0.0.0", "") else host
    key = "configured" if os.environ.get("GEMINI_API_KEY") else "not set — assistant uses the rule engine"
    print("")
    print("  SchemeWise API")
    print("  " + "-" * 58)
    print("  app       http://%s:%d" % (display, port))
    print("  health    http://%s:%d/api/health" % (display, port))
    print("  api docs  http://%s:%d/api/docs" % (display, port))
    print("  routes    %d endpoints" % route_count)
    print("  gemini    %s" % key)
    if host == "0.0.0.0":
        print("  network   reachable from other devices on this wifi")
    print("  " + "-" * 58)
    print("  Ctrl+C to stop.")
    print("")


def main():
    parser = argparse.ArgumentParser(description="Run the SchemeWise backend")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8000)))
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--reset", action="store_true", help="delete the database and reseed")
    args = parser.parse_args()

    load_env()

    if args.reset and os.path.exists(db.DB_PATH):
        os.remove(db.DB_PATH)
        for suffix in ("-wal", "-shm"):
            side = db.DB_PATH + suffix
            if os.path.exists(side):
                os.remove(side)
        print("  database reset")

    print("")
    print("  starting SchemeWise…")
    db.init()

    app = create_app()
    route_count = len(app.routes)
    banner(args.host, args.port, route_count)

    if not args.no_browser:
        url = "http://%s:%d" % ("localhost" if args.host in ("0.0.0.0", "") else args.host, args.port)
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    try:
        run(app, args.host, args.port, static_root=make_static_handler())
    except KeyboardInterrupt:
        print("\n  stopped.\n")
    except OSError as e:
        if getattr(e, "errno", None) in (48, 98, 10048):
            print("\n  Port %d is already in use." % args.port)
            print("  Another copy of the server is probably running.")
            print("  Try:  python backend/server.py --port %d\n" % (args.port + 1))
        else:
            raise


if __name__ == "__main__":
    main()
