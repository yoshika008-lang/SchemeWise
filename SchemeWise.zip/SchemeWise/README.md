# SchemeWise

Government scheme discovery for Indian citizens: answer four short questions,
get a ranked, explained verdict on 24 real central and state programmes — plus
what it is worth in rupees, which documents you need, and which office will
actually accept your form.

**Full stack.** A Python backend with a SQLite database, a rule engine, an
authenticated admin console with an audit trail, and a grounded AI assistant.
The browser draws the answer; it does not decide it.

---

## Run it

You need Python 3.8 or newer. Nothing else. **No `pip install`, no database
server, no internet connection.**

**Windows** — double-click `START-BACKEND.bat`

**Anything else**

```bash
cd SchemeWise
python backend/server.py
```

Then open **http://localhost:8000**. On first run the server creates the
database, loads 24 scheme records and 15 offices, and creates the staff
accounts. That takes about a second.

To check everything works before a demo:

```bash
python backend/selftest.py
```

That runs 43 checks end to end — matching, loan maths, office ranking,
password hashing, token forgery, input validation, the assistant and the audit
trail — and prints a single pass/fail line.

### Useful flags

```bash
python backend/server.py --port 8080     # if 8000 is taken
python backend/server.py --host 0.0.0.0  # reach it from your phone on the same wifi
python backend/server.py --reset         # wipe the database and reseed
python backend/server.py --no-browser    # don't open a browser window
```

---

## What is where

```
SchemeWise/
├── START-BACKEND.bat        double-click to run (Windows)
│
├── backend/
│   ├── server.py            entry point: starts the API and serves the page
│   ├── app.py               the web framework (routing, requests, responses)
│   ├── db.py                SQLite schema, seeding, the audit helper
│   ├── security.py          password hashing, signed tokens, rate limits
│   ├── manage.py            change admin passwords, reset demo data
│   ├── selftest.py          43 end-to-end checks
│   │
│   ├── engine/              ← the part that decides things
│   │   ├── rules.py         pass / warn / fail primitives
│   │   ├── catalogue.py     the rule set for each of the 24 schemes
│   │   ├── matcher.py       eligibility, scoring, subsidy
│   │   ├── finance.py       EMI, moratorium interest, amortisation
│   │   └── geo.py           which office can actually take your form
│   │
│   ├── routes/              ← the HTTP surface, one file per area
│   │   ├── auth_routes.py       sessions, citizen accounts, admin sign-in
│   │   ├── scheme_routes.py     the catalogue and reference data
│   │   ├── match_routes.py      POST /api/match — the core endpoint
│   │   ├── profile_routes.py    profile, shortlist, document checklist
│   │   ├── finance_routes.py    the calculator
│   │   ├── partner_routes.py    office ranking
│   │   ├── ai_routes.py         the assistant (holds the Gemini key)
│   │   ├── admin_routes.py      scheme editing + audit + analytics
│   │   └── meta_routes.py       health, self-describing API docs
│   │
│   ├── seed/                the 24 scheme records, offices, districts (JSON)
│   └── data/                the database, created on first run
│
├── frontend/
│   └── index.html           the whole UI — presentation only
│
└── docs/
    ├── ARCHITECTURE.md      how the pieces fit, and why
    ├── API.md               every endpoint with examples
    └── DEMO-SCRIPT.md       what to say to a judge, minute by minute
```

---

## The one design decision that matters

A scheme has two halves, and they are stored in two different places on
purpose:

| | Lives in | Changed by | Why |
|---|---|---|---|
| **The record** — ceilings, interest range, documents, verification date | the `schemes` table | an administrator, through the admin screen | Government orders revise these figures. Staff must be able to fix them without a developer. |
| **The rule** — "under 45 unless SC/ST/women", "Class VIII above ₹10 lakh" | `backend/engine/catalogue.py` | a code change, reviewed and versioned | These are legal tests. Every change should be a reviewable commit, not a text box someone retypes at 2 a.m. |

Every match response carries the rule version (`2026.09.1`) that produced it,
so a verdict given last month can always be reproduced against the rules that
produced it.

---

## Security

- Passwords are stored as **scrypt** hashes with a per-user random salt. The
  database file contains no readable password.
- Tokens are **HMAC-SHA256 signed**. Edit one character and the signature
  stops matching, so nobody can promote themselves to admin.
- Every value from a browser goes through an **allowlist validator** before it
  reaches a rule or the database. Unknown fields are dropped; numbers are
  clamped to a legal range.
- All SQL is **parameterised**. No string concatenation anywhere.
- **Rate limits** per IP, tighter on sign-in and AI calls than on reads.
- The **Gemini key never leaves the server**. `GET /api/ai/status` confirms it.
- Every administrator action writes an **append-only audit row** with the
  username, timestamp, IP and before/after values.

Before letting anyone else reach your machine, change the demo passwords:

```bash
python backend/manage.py set-admin-password admin
```

---

## Optional: turn on the language model

The assistant works without one — it answers directly from the rule engine,
which is why the demo cannot be broken by venue wifi. To add Gemini on top:

1. Get a free key at https://aistudio.google.com/apikey
2. `cp backend/.env.example backend/.env`
3. Put the key in `GEMINI_API_KEY=`
4. Restart the server

Either way the model is never the source of truth: the server runs the rule
engine first and injects that verdict into the prompt as the only facts the
model is allowed to use. It cannot invent a scheme, because it is handed the
exact list and told to stay inside it.

---

## Demo accounts

| Username | Password | Role |
|---|---|---|
| `admin` | `scheme@2025` | super_admin — can edit and publish |
| `verifier` | `verify@2025` | verification_officer |

These are rows in the `admin_users` table with hashed passwords, checked by
`POST /api/admin/login`.

---

## A note on the data

The 24 programmes are real, and every figure was checked against the official
portal listed on each record, on the date shown in `lastVerified`. Interest
rates set by lenders rather than by the scheme are stored as indicative ranges
and labelled as such in the UI.

The office directory is sample data: the institutions and their roles are real,
but addresses and coordinates are approximate and the app says so. No live
availability, funding or utilisation status is claimed anywhere.
