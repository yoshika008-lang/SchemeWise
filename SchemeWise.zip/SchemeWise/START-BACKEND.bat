@echo off
REM ===================================================================
REM  SchemeWise - one-click start for Windows
REM  Double-click this file. It starts the backend and opens the app.
REM ===================================================================

title SchemeWise backend
cd /d "%~dp0"

echo.
echo   SchemeWise
echo   ------------------------------------------------------------
echo   Starting the backend. Keep this window open during your demo.
echo   Closing this window stops the app.
echo.

REM Find Python. "py" is the Windows launcher; "python" is the fallback.
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 backend\server.py %*
    goto done
)

where python >nul 2>nul
if %errorlevel%==0 (
    python backend\server.py %*
    goto done
)

echo   Python was not found on this computer.
echo.
echo   Install it from https://www.python.org/downloads/
echo   and tick "Add Python to PATH" during setup.
echo.

:done
echo.
echo   The server has stopped.
pause
